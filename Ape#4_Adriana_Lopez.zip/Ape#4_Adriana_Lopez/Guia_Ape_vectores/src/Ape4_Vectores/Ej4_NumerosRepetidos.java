package Ape4_Vectores;

import java.util.Scanner;
import java.util.HashMap;

public class Ej4_NumerosRepetidos {

    public static int[] leerNumeros() {
        Scanner scanner = new Scanner(System.in);
        int[] numeros = new int[6];

        System.out.println("Ingrese 6 números:");
        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

        return numeros;
    }

    public static int contarRepetidos(int[] arreglo) {
        HashMap<Integer, Integer> frecuencia = new HashMap<>();
        int repetidos = 0;

        for (int num : arreglo) {
            frecuencia.put(num, frecuencia.getOrDefault(num, 0) + 1);
        }


        for (int valor : frecuencia.values()) {
            if (valor > 1) {
                repetidos++;
            }
        }

        return repetidos;
    }

    public static void main(String[] args) {
        int[] numeros = leerNumeros();
        int cantidadRepetidos = contarRepetidos(numeros);

        System.out.println("\nCantidad de números repetidos: " + cantidadRepetidos);
    }
}

