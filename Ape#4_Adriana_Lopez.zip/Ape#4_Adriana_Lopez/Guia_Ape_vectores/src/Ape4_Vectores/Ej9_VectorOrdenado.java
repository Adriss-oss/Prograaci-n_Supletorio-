package Ape4_Vectores;

import java.util.Arrays;
import java.util.Random;

public class Ej9_VectorOrdenado {

    public static void main(String[] args) {
        int[] numeros = new int[10]; 
        Random random = new Random();

        // Inicializar el vector con valores aleatorios entre 0 y 100
        for (int i = 0; i < numeros.length; i++) {
            numeros[i] = random.nextInt(101); // entre 0 y 100 inclusive
        }

        // Mostrar el vector original
        System.out.println("Vector original:");
        for (int num : numeros) {
            System.out.print(num + " ");
        }

        // Ordenar el vector de menor a mayor
        Arrays.sort(numeros);

        // Mostrar el vector ordenado
        System.out.println("\n\nVector ordenado (menor a mayor):");
        for (int num : numeros) {
            System.out.print(num + " ");
        }
    }
}
