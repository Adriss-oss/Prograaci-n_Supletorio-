package Ape4_Vectores;

import java.util.Scanner;
import java.util.Arrays;
import java.util.Collections;

public class Ej3_OrdenarNumeros {

    public static Integer[] leerNumeros() {
        Scanner scanner = new Scanner(System.in);
        Integer[] numeros = new Integer[5];

        System.out.println("Ingrese 5 números:");
        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

        return numeros;
    }

    public static char leerOpcionOrden() {
        Scanner scanner = new Scanner(System.in);
        char opcion;

        do {
            System.out.print("Ingrese 'A' para ordenar Ascendentemente o 'D' para Descendentemente: ");
            opcion = scanner.next().toUpperCase().charAt(0);
        } while (opcion != 'A' && opcion != 'D');

        return opcion;
    }

    public static void ordenarNumeros(Integer[] arreglo, char tipo) {
        if (tipo == 'A') {
            Arrays.sort(arreglo);
        } else {
            Arrays.sort(arreglo, Collections.reverseOrder());
        }
    }

    public static void mostrarArreglo(Integer[] arreglo) {
        System.out.println("Números ordenados:");
        for (int num : arreglo) {
            System.out.print(num + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Integer[] numeros = leerNumeros();
        char tipoOrden = leerOpcionOrden();
        ordenarNumeros(numeros, tipoOrden);
        mostrarArreglo(numeros);
    }
}
