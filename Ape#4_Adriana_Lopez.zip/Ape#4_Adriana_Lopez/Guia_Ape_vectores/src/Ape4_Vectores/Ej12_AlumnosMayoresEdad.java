package Ape4_Vectores;

import java.util.ArrayList;
import java.util.Scanner;

public class Ej12_AlumnosMayoresEdad {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        ArrayList<String> nombres = new ArrayList<>();
        ArrayList<Integer> edades = new ArrayList<>();

        System.out.println("Ingrese el nombre y la edad de los alumnos (escriba * como nombre para terminar):");

        while (true) {
            System.out.print("Nombre: ");
            String nombre = scanner.nextLine();

            if (nombre.equals("*")) {
                break;
            }

            System.out.print("Edad: ");
            int edad = Integer.parseInt(scanner.nextLine());

            nombres.add(nombre);
            edades.add(edad);
        }

        // Mostrar alumnos mayores de edad
        System.out.println(" Alumnos mayores de edad (18 años o más):");
        boolean hayMayores = false;
        for (int i = 0; i < nombres.size(); i++) {
            if (edades.get(i) >= 18) {
                System.out.println("- " + nombres.get(i) + " (" + edades.get(i) + " años)");
                hayMayores = true;
            }
        }

        if (!hayMayores) {
            System.out.println("Ningún alumno es mayor de edad.");
        }
    }
}

