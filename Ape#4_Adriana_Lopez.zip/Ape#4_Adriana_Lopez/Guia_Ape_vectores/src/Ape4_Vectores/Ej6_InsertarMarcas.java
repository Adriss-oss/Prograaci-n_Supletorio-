package Ape4_Vectores;

import java.util.Arrays;
import java.util.Arrays;

public class Ej6_InsertarMarcas {
    public static void main(String[] args) {
        // Arreglo original con 6 marcas en orden alfabético
        String[] cochesOriginal = {"Audi", "BMW", "Ford", "Hyundai", "Kia", "Toyota"};

        // Crear un nuevo arreglo de 8 elementos
        String[] cochesFinal = new String[8];

        // Copiar las 6 marcas al nuevo arreglo
        for (int i = 0; i < cochesOriginal.length; i++) {
            cochesFinal[i] = cochesOriginal[i];
        }

        // Insertar las nuevas marcas
        cochesFinal[6] = "Opel";
        cochesFinal[7] = "Citroen";

        // Ordenar alfabéticamente el arreglo completo
        Arrays.sort(cochesFinal);

        // Mostrar el resultado final
        System.out.println("Marcas de coches ordenadas alfabéticamente:");
        for (String marca : cochesFinal) {
            System.out.println(marca);
        }
    }

}

