package Ape4_Vectores;

import java.util.Scanner;

public class Ej13_Temperaturas {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double[] tempMin = new double[5];
        double[] tempMax = new double[5];
        double[] tempMedia = new double[5];

        System.out.println("Ingrese las temperaturas mínimas y máximas de 5 días:");

        for (int i = 0; i < 5; i++) {
            System.out.println("\nDía " + (i + 1) + ":");
            System.out.print("Temperatura mínima: ");
            tempMin[i] = scanner.nextDouble();

            System.out.print("Temperatura máxima: ");
            tempMax[i] = scanner.nextDouble();

            tempMedia[i] = (tempMin[i] + tempMax[i]) / 2;
        }

        // Mostrar la temperatura media de cada día
        System.out.println("Temperatura media de cada día:");
        for (int i = 0; i < 5; i++) {
            System.out.printf("Día %d: %.2f°C\n", (i + 1), tempMedia[i]);
        }

        // Buscar el día con la temperatura media más baja y más alta
        int diaMin = 0;
        int diaMax = 0;

        for (int i = 1; i < 5; i++) {
            if (tempMedia[i] < tempMedia[diaMin]) {
                diaMin = i;
            }
            if (tempMedia[i] > tempMedia[diaMax]) {
                diaMax = i;
            }
        }

        System.out.printf(" Día con la temperatura media más baja: Día %d (%.2f°C)\n", diaMin + 1, tempMedia[diaMin]);
        System.out.printf(" Día con la temperatura media más alta: Día %d (%.2f°C)\n", diaMax + 1, tempMedia[diaMax]);
    }
}
