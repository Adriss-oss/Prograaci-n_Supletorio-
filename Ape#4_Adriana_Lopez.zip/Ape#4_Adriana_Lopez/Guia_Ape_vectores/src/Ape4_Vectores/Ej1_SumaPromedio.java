package Ape4_Vectores;

import java.util.Scanner;

public class Ej1_SumaPromedio {

    public static int[] leerNumeros() {
        Scanner scanner = new Scanner(System.in);
        int[] vector = new int[4];

        System.out.println("Ingrese 4 números:");
        for (int i = 0; i < vector.length; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            vector[i] = scanner.nextInt();
        }

        return vector;
    }

    public static int calcularSuma(int[] arreglo) {
        int suma = 0;
        for (int num : arreglo) {
            suma += num;
        }
        return suma;
    }


    public static double calcularPromedio(int suma, int cantidad) {
        return (double) suma / cantidad;
    }


    public static void main(String[] args) {
        int[] numeros = leerNumeros();
        int suma = calcularSuma(numeros);
        double promedio = calcularPromedio(suma, numeros.length);

        System.out.println("\nSuma de los números: " + suma);
        System.out.println("Promedio de los números: " + promedio);
    }
}

