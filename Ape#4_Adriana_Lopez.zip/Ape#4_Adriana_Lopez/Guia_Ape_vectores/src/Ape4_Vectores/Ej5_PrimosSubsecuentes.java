package Ape4_Vectores;

import java.util.Scanner;

public class Ej5_PrimosSubsecuentes {


    public static boolean esPrimo(int numero) {
        if (numero < 2) return false;
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) return false;
        }
        return true;
    }


    public static int[] encontrarPrimos(int n) {
        int[] primos = new int[10];
        int contador = 0;
        int numero = n + 1;

        while (contador < 10) {
            if (esPrimo(numero)) {
                primos[contador] = numero;
                contador++;
            }
            numero++;
        }

        return primos;
    }

    public static int calcularSuma(int[] arreglo) {
        int suma = 0;
        for (int num : arreglo) {
            suma += num;
        }
        return suma;
    }


    public static double calcularPromedio(int suma, int cantidad) {
        return (double) suma / cantidad;
    }


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese un número n: ");
        int n = scanner.nextInt();

        int[] primos = encontrarPrimos(n);
        int suma = calcularSuma(primos);
        double promedio = calcularPromedio(suma, primos.length);

        System.out.println("\nLos primeros 10 números primos mayores que " + n + " son:");
        for (int primo : primos) {
            System.out.print(primo + " ");
        }

        System.out.println("\n\nSuma de los primos: " + suma);
        System.out.println("Promedio de los primos: " + promedio);
    }
}

