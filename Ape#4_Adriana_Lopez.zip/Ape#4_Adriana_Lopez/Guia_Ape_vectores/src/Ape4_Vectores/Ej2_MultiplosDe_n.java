package Ape4_Vectores;

import java.util.Scanner;

public class Ej2_MultiplosDe_n {

    public static int[] leerNumeros() {
        Scanner scanner = new Scanner(System.in);
        int[] numeros = new int[6];

        System.out.println("Ingrese 6 números:");
        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

        return numeros;
    }

    public static int leerNumeroN() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nIngrese el número n para verificar múltiplos: ");
        return scanner.nextInt();
    }

    public static int contarMultiplos(int[] arreglo, int n) {
        int contador = 0;
        for (int num : arreglo) {
            if (num % n == 0) {
                contador++;
            }
        }
        return contador;
    }

    public static void main(String[] args) {
        int[] numeros = leerNumeros();
        int n = leerNumeroN();
        int cantidadMultiplos = contarMultiplos(numeros, n);

        System.out.println("\nCantidad de múltiplos de " + n + ": " + cantidadMultiplos);
    }
}

