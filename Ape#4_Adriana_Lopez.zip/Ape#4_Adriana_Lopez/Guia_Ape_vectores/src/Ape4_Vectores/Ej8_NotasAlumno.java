package Ape4_Vectores;

import java.util.Scanner;

public class Ej8_NotasAlumno {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double[] notas = new double[5];
        double suma = 0;
        double notaMayor, notaMenor;

        System.out.println("Ingrese las 5 notas del alumno (valores entre 0 y 10):");
        for (int i = 0; i < notas.length; i++) {
            double nota;
            do {
                System.out.print("Nota " + (i + 1) + ": ");
                nota = scanner.nextDouble();
                if (nota < 0 || nota > 10) {
                    System.out.println("Error: la nota debe estar entre 0 y 10.");
                }
            } while (nota < 0 || nota > 10);
            notas[i] = nota;
            suma += nota;
        }

        // Inicializar mayor y menor con la primera nota
        notaMayor = notas[0];
        notaMenor = notas[0];

        // Encontrar nota mayor y menor
        for (int i = 1; i < notas.length; i++) {
            if (notas[i] > notaMayor) {
                notaMayor = notas[i];
            }
            if (notas[i] < notaMenor) {
                notaMenor = notas[i];
            }
        }

        double media = suma / notas.length;

        //  resultados
        System.out.println("Notas ingresadas:");
        for (double nota : notas) {
            System.out.println(nota);
        }
        System.out.println("\nNota media: " + media);
        System.out.println("Nota más alta: " + notaMayor);
        System.out.println("Nota más baja: " + notaMenor);
    }
}

