import java.util.Scanner;

public class Examen_part_2 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int num1,res,num,res2;
        System.out.println("Ingreasr un numero para verificar si es cubo perfeecto o no:");
        num1=teclado.nextInt();
        res=num1/100;
        res2=res%res;

        num=num1%res;

        System.out.println(" "+res+" "+num+" "+res2);
    
        
    }

}
