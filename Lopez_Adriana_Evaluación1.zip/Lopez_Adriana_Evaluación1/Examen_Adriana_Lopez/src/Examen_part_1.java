import java.util.Scanner;

public class Examen_part_1 {
    public static void main(String[] args) throws Exception {
        Scanner teclado = new Scanner(System.in);
        float monto,cliente,pago,desc,recargo;
        String tip_cliente,form_pago;

        System.out.print("Ingresar el monto de consumo: ");
        monto=teclado.nextFloat();
        System.out.println("Ingresar el tipo de cliente:");
        System.out.println("Cliente genral(G)");
        System.out.println("Cliente afiliado(A)");
        tip_cliente=teclado.next();
        switch (tip_cliente) {
            case "G" : 
             cliente=0.15f;
             System.out.println("Se aplica un descuento del 15%");
                break;
            case "A":  
            cliente=0.20f; 
            System.out.println("Se aplica un descuento del 20%");
            break;
            default:
            System.out.println("Ingresar una opción valida ");
                throw new AssertionError();
        }
        System.out.println("Ingresar la fporma de pago: ");
        System.out.println("Al contado(C)");
        System.out.println("A plazos(P)");
        form_pago=teclado.next();
        switch (form_pago) {
            case "C" : 
             pago=0.10f;
             System.out.println("Se aplicara un recargo de 10%");
                break;
            case "P" :  
            pago=0.05f; 
            System.out.println("Se aplicara un recargo de 5%");
            break;
            default:
            System.out.println("Ingresar una opción valida ");
                throw new AssertionError();
        }
       
        desc=monto-(monto*cliente);
        recargo=desc+(monto*pago);
        
        System.out.println("El monto con el descuento aplicado es de: "+desc);
        System.out.println("El monto total a pagar con el descuento y el recargo aplicado son: "+recargo);




        



        System.out.println("Hello, World!");
    }
}
