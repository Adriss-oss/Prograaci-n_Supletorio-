import turtle
import random
import math
import time

# Configurar ventana
wn = turtle.Screen()
wn.title("Juego: Disparo al Avión")
wn.bgcolor("skyblue")
wn.setup(width=800, height=600)

# Crear el tanque (base + cañón)
def crear_tanque():
    base = turtle.Turtle()
    base.shape("square")
    base.color("darkgreen")
    base.shapesize(stretch_wid=2, stretch_len=4)
    base.penup()
    base.goto(-350, -260)

    torreta = turtle.Turtle()
    torreta.shape("circle")
    torreta.color("green")
    torreta.shapesize(stretch_wid=1.5)
    torreta.penup()
    torreta.goto(-350, -240)

    canion = turtle.Turtle()
    canion.shape("square")
    canion.color("black")
    canion.shapesize(stretch_wid=0.3, stretch_len=2)
    canion.penup()
    canion.goto(-350, -230)
    canion.setheading(90)

    return base, torreta, canion

# Crear el avión
plane = turtle.Turtle()
plane.shape("triangle")
plane.color("red")
plane.penup()
plane.speed(0)

# Crear el misil
missile = turtle.Turtle()
missile.shape("circle")
missile.color("black")
missile.penup()
missile.hideturtle()
missile.speed(0)

# Trazo de trayectoria
trayectoria = turtle.Turtle()
trayectoria.hideturtle()
trayectoria.penup()
trayectoria.speed(0)
trayectoria.color("red")

# Función para calcular distancia
def distancia(p1, p2):
    return math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)

def jugar():
    vidas = 3

    # Elegir tipo de coordenadas
    modo = turtle.textinput("Coordenadas del avión", "¿Quieres ingresar las coordenadas? (si/no):").lower()
    if modo == "si":
        x_plane = wn.numinput("Coordenada X", "Ingresa la coordenada X del avión (100 a 350):", minval=100, maxval=350)
        y_plane = wn.numinput("Coordenada Y", "Ingresa la coordenada Y del avión (0 a 250):", minval=0, maxval=250)
    else:
        x_plane = random.randint(100, 350)
        y_plane = random.randint(0, 250)

    plane.goto(x_plane, y_plane)

    while vidas > 0:
        # Pedir ángulo
        angulo = wn.numinput("Ángulo de disparo", f"Te quedan {vidas} intento(s). Ingresa el ángulo (0-90):", minval=0, maxval=90)
        if angulo is None:
            break

        # Preparar el misil
        missile.goto(-350, -250)
        missile.setheading(angulo)
        missile.showturtle()

        # Preparar trayectoria
        trayectoria.clear()
        trayectoria.goto(missile.pos())
        trayectoria.setheading(angulo)

        velocidad = 10
        paso = 0
        while missile.xcor() < 400 and missile.ycor() < 300:
            missile.forward(velocidad)
            paso += 1

            # Línea interlineada: dibujar 1 paso sí, 1 paso no
            if paso % 2 == 0:
                trayectoria.pendown()
            else:
                trayectoria.penup()

            trayectoria.goto(missile.pos())
            time.sleep(0.03)

            if distancia(missile.pos(), plane.pos()) < 25:
                turtle.textinput("¡Has ganado!", "¡Le diste al avión! Presiona Enter para continuar.")
                return

        missile.hideturtle()
        vidas -= 1
        if vidas > 0:
            turtle.textinput("Fallaste", f"No acertaste. Te quedan {vidas} intento(s). Presiona Enter para continuar.")
        else:
            turtle.textinput("Game Over", "Has perdido todas tus vidas. Presiona Enter para salir.")

# Bucle principal
base, torreta, canion = crear_tanque()

while True:
    jugar()
    retry = turtle.textinput("¿Otra vez?", "¿Quieres jugar de nuevo? (si/no):")
    if retry is None or retry.lower() != "si":
        break

turtle.bye()

