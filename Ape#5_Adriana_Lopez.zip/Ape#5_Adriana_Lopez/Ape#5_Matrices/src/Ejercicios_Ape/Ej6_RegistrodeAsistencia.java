package Ejercicios_Ape;

import java.util.Scanner;

public class Ej6_RegistrodeAsistencia {

    public static void registrarAsistencia(int[][] asistencia, Scanner teclado) {
        for (int i = 0; i < 4; i++) {
            System.out.println("Ingrese la asistencia para la Facultad " + (i + 1) + ":");
            for (int j = 0; j < 5; j++) {
                System.out.print("Materia " + (j + 1) + ": ");
                asistencia[i][j] = teclado.nextInt();
            }
        }
    }

    public static void mostrarAsistenciaTotalPorMateria(int[][] asistencia) {
        System.out.println("\nAsistencia total por materia:");
        for (int j = 0; j < 5; j++) {
            int totalMateria = 0;
            for (int i = 0; i < 4; i++) {
                totalMateria += asistencia[i][j];
            }
            System.out.println("Materia " + (j + 1) + ": " + totalMateria);
        }
    }

    public static void mostrarAsistenciaFacultad3(int[][] asistencia) {
        int totalFacultad3 = 0;
        for (int j = 0; j < 5; j++) {
            totalFacultad3 += asistencia[2][j]; 
        }
        System.out.println("\nAsistencia total en la Facultad 3: " + totalFacultad3);
    }

    public static void mostrarAsistenciaMateria2Facultad1(int[][] asistencia) {
        int asistenciaMateria2Facultad1 = asistencia[0][1]; 
        System.out.println("\nAsistencia en la Materia 2 de la Facultad 1: " + asistenciaMateria2Facultad1);
    }
    public static void mostrarPorcentajeAsistenciaPorFacultad(int[][] asistencia) {
        System.out.println("\nPorcentaje de asistencia en cada facultad:");
        for (int i = 0; i < 4; i++) {
            int totalFacultad = 0;
            for (int j = 0; j < 5; j++) {
                totalFacultad += asistencia[i][j];
            }
            double porcentaje = (totalFacultad / 5.0) * 100;
            System.out.println("Facultad " + (i + 1) + ": " + porcentaje + "%");
        }
    }

    public static void determinarFacultadMayorAsistencia(int[][] asistencia) {
        int maxAsistencia = 0;
        int facultadMayorAsistencia = -1;
        for (int i = 0; i < 4; i++) {
            int totalFacultad = 0;
            for (int j = 0; j < 5; j++) {
                totalFacultad += asistencia[i][j];
            }
            if (totalFacultad > maxAsistencia) {
                maxAsistencia = totalFacultad;
                facultadMayorAsistencia = i;
            }
        }
        System.out.println("\nLa facultad con la mayor asistencia es la Facultad " + (facultadMayorAsistencia + 1));
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        int[][] asistencia = new int[4][5];

        registrarAsistencia(asistencia, teclado);
        mostrarAsistenciaTotalPorMateria(asistencia);
        mostrarAsistenciaFacultad3(asistencia);
        mostrarAsistenciaMateria2Facultad1(asistencia);
        mostrarPorcentajeAsistenciaPorFacultad(asistencia);
        determinarFacultadMayorAsistencia(asistencia);
    }

}
