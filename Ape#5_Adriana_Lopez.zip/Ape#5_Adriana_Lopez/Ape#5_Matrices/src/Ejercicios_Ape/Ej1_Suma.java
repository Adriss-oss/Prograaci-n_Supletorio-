package Ejercicios_Ape;

import java.util.Random;

public class Ej1_Suma {

    public static void llenarMatriz(int[][] matriz) {
        Random random = new Random();
        System.out.println("Generación de los valores para la matriz 5x5:");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                matriz[i][j] = random.nextInt(1, 20); // Rango de 1 a 19
            }
        }
    }

    // mostrar la matriz cargada con la suma al lado de cada fila
    public static void mostrarMatriz(int[][] matriz, int[] sumaPorFila) {
        System.out.println("Matriz cargada con sumas por fila:");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(matriz[i][j] + "\t");
            }
            System.out.println("| Suma: " + sumaPorFila[i]);
        }
    }

    // elementos de cada fila sumados
    public static void sumaPorFila(int[][] matriz, int[] sumaPorFila) {
        for (int i = 0; i < 5; i++) {
            int sumaFila = 0;
            for (int j = 0; j < 5; j++) {
                sumaFila += matriz[i][j];
            }
            sumaPorFila[i] = sumaFila;
        }
    }

    // Los elementos de cada columna sumados debajo de la columna
    public static void sumaPorColumna(int[][] matriz) {
        System.out.println("Suma ");
        for (int j = 0; j < 5; j++) {
            int sumaColumna = 0;
            for (int i = 0; i < 5; i++) {
                sumaColumna += matriz[i][j];
            }
            System.out.print((j + 1) + ": " + sumaColumna + "\t");
        }
        System.out.println(); // Para salto de línea al final
    }

    public static void main(String[] args) {
        // matriz 5x5
        int[][] matriz = new int[5][5];
        // Array para guardar las sumas de las filas
        int[] sumaPorFila = new int[5];

        // Instanciar y llenar la matriz
        llenarMatriz(matriz);
        sumaPorFila(matriz, sumaPorFila);
        mostrarMatriz(matriz, sumaPorFila);
        sumaPorColumna(matriz);
    }
}
