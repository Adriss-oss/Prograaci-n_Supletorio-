package Ejercicios_Ape;

import java.util.Scanner;

public class Ej7_Matricesnxn {

    //ingresar la matriz de tamaño n x n
    public static int[][] ingresarMatriz(int n, Scanner teclado) {
        int[][] matriz = new int[n][n];
        System.out.println("Ingresa los elementos de la matriz:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matriz[i][j] = teclado.nextInt();
            }
        }
        return matriz;
    }
    //imprimir la matriz
    public static void imprimirMatriz(int[][] matriz) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println();
        }
    }

    // Sumar dos matrices
    public static int[][] sumarMatrices(int[][] matriz1, int[][] matriz2) {
        int n = matriz1.length;
        int[][] suma = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                suma[i][j] = matriz1[i][j] + matriz2[i][j];
            }
        }
        return suma;
    }

    //calcular el promedio de los elementos de las matrices
    public static double calcularPromedio(int[][] matriz1, int[][] matriz2) {
        int sumaTotal = 0;
        int totalElementos = matriz1.length * matriz1[0].length * 2; // Ambas matrices
        for (int i = 0; i < matriz1.length; i++) {
            for (int j = 0; j < matriz1[i].length; j++) {
                sumaTotal += matriz1[i][j];
                sumaTotal += matriz2[i][j];
            }
        }
        return (double) sumaTotal / totalElementos;
    }

    //Multiplicar dos matrices
    public static int[][] multiplicarMatrices(int[][] matriz1, int[][] matriz2) {
        int n = matriz1.length;
        int[][] producto = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    producto[i][j] += matriz1[i][k] * matriz2[k][j];
                }
            }
        }
        return producto;
    }

    // Mayor elemento de una matriz
    public static int encontrarMayorElemento(int[][] matriz) {
        int max = matriz[0][0];
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                if (matriz[i][j] > max) {
                    max = matriz[i][j];
                }
            }
        }
        return max;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        // Ingresar el tamaño de la matriz
        System.out.print("Ingresa el tamaño de la matriz (n): ");
        int n = teclado.nextInt();

        // Ingreso de las dos matrices
        System.out.println("Ingresando la primera matriz:");
        int[][] matriz1 = ingresarMatriz(n, teclado);
        System.out.println("Ingresando la segunda matriz:");
        int[][] matriz2 = ingresarMatriz(n, teclado);

        // Suma de las  matrices
        int[][] suma = sumarMatrices(matriz1, matriz2);
        System.out.println("Matriz resultante de la suma:");
        imprimirMatriz(suma);

        // Promedio de los elementos
        double promedio = calcularPromedio(matriz1, matriz2);
        System.out.println("Promedio de todos los elementos de las dos matrices: " + promedio);

        // Producto de matrices
        int[][] producto = multiplicarMatrices(matriz1, matriz2);
        System.out.println("Matriz resultante del producto:");
        imprimirMatriz(producto);
        
        // Mayor elemento de la matriz suma
        int mayorElemento = encontrarMayorElemento(suma);
        System.out.println("El mayor elemento de la matriz suma es: " + mayorElemento);

    }
}
