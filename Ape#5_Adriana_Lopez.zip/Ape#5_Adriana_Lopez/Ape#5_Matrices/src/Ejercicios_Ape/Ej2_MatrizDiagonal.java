package Ejercicios_Ape;

public class Ej2_MatrizDiagonal {
    public static void cargarMatrizDiagonal(int[][] matriz) {
        for (int i = 0; i < matriz.length; i++) { // Recorre las filas
            for (int j = 0; j < matriz[i].length; j++) { // Recorre las columnas
                if (i == j) { //El elemento SI está en la diagonal principal
                    matriz[i][j] = 1;
                } else { //El elemento NO está en la diagonal principal
                    matriz[i][j] = 0;
                }
            }
        }
    }

    public static void mostrarMatriz(int[][] matriz) {
        System.out.println("Contenido de la tabla 'diagonal':");
        for (int i = 0; i < matriz.length; i++) { 
            for (int j = 0; j < matriz[i].length; j++) { 
                System.out.print(matriz[i][j] + " "); // Imprime el valor y un espacio
            }
            System.out.println(); // Salto de línea al final de cada fila
        }
    }
     public static void main(String[] args) {
        //tabla bidimensional de 5x5
        int[][] diagonal = new int[5][5];
        cargarMatrizDiagonal(diagonal);
        mostrarMatriz(diagonal);
    }
}
