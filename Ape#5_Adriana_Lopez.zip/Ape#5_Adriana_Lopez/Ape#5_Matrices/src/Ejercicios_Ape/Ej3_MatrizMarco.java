package Ejercicios_Ape;


public class Ej3_MatrizMarco {
    private static final int Num_filas = 5;
    private static final int Num_columnas = 15;

    public static void cargarMatrizMarco(int[][] matriz) {
        for (int i = 0; i < matriz.length; i++) { // Recorre las filas
            for (int j = 0; j < matriz[i].length; j++) { // Recorre las columnas
                // SI el elemento está en la primera fila, última fila, primera columna o última
                // columna
                if (i == 0 || i == matriz.length - 1 || j == 0 || j == matriz[i].length - 1) {
                    matriz[i][j] = 1;
                } else { // SI el elemento está en el interior de la matriz
                    matriz[i][j] = 0;
                }
            }
        }
    }

    public static void visualizarMatriz(int[][] matriz) {
        System.out.println("Contenido de la tabla Marco:");
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print(matriz[i][j]); // Imprime el valor
            }
            System.out.println(); // Salto de línea al final de cada fila
        }
    }

    public static void main(String[] args) {
        // Crear la matriz
        int[][] marco = new int[Num_filas][Num_columnas];
        cargarMatrizMarco(marco);
        visualizarMatriz(marco);
    }
}
