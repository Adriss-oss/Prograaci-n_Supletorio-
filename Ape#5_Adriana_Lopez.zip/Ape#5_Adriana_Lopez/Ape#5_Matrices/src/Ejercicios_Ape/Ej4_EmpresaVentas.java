package Ejercicios_Ape;

import java.util.Random;

public class Ej4_EmpresaVentas {

    public static void main(String[] args) {
        int[] cantidadesporArticulo = new int[5];
        double[] precioarticulos = new double[] { 10, 20, 30, 40, 50 };
        int[][] cantidades = {
                { 5, 6, 3, 5, 7 },
                { 4, 5, 4, 6, 10 },
                { 10, 4, 4, 10, 2 },
                { 8, 3, 6, 5, 3 }
        };
        double recaudacion[][] = new double[4][5];
        int sumatoriacantidades = 0;
        
        double[] Recaudacionsucursal = new double[4];
        // 1)LA CANTIDADES TOTALES DE CADA ARTICULO
        System.out.println("pregunta # 1");
        System.out.println("LA CANTIDADES TOTALES DE CADA ARTICULO");
        for (int c = 0; c < cantidades[0].length; c++) {
            sumatoriacantidades = 0;
            for (int f = 0; f < cantidades.length; f++) {
                sumatoriacantidades += cantidades[f][c];

            }
            cantidadesporArticulo[c] = sumatoriacantidades;
            // System.out.println("ARTICULO "+ (c+1)+" = "+sumatoriacantidades);
        }
        for (int i = 0; i < cantidadesporArticulo.length; i++) {
            System.out.println("ARTICULO " + (i + 1) + " = " + cantidadesporArticulo[i]);
        }
        // -----------------------------------------------------------
        // 2) la cantidades de articulos en la sucursal 2
        System.out.println("pregunta # 2");
        System.out.println("la cantidades de articulos en la sucursal 2");
        sumatoriacantidades = 0;
        for (int c = 0; c < cantidades[0].length; c++) {
            sumatoriacantidades += cantidades[1][c];

        }
        System.out.println("ARTICULOS  de la surcursal 2 = " + sumatoriacantidades);
        // -----------------------------------------------------------
        // 3) • La cantidad del articulo 3 en la sucursal 1.
        System.out.println("pregunta # 3");
        System.out.println("La cantidad del articulo 3 en la sucursal 1.");
        System.out.println("LA CANTIDAD = " + cantidades[0][2]);
        // -----------------------------------------------------------
        // 4) • La recaudación total de cada sucursal.
        System.out.println("pregunta # 4");
        System.out.println(" La recaudación total de cada sucursal.");

        for (int f = 0; f < recaudacion.length; f++) {
            for (int c = 0; c < recaudacion[0].length; c++) {
                recaudacion[f][c] = cantidades[f][c] * precioarticulos[c];

            }
        }
        sumatoriacantidades = 0;

        for (int f = 0; f < recaudacion.length; f++) {
            sumatoriacantidades = 0;
            for (int c = 0; c < recaudacion[0].length; c++) {
                sumatoriacantidades += recaudacion[f][c];

            }
            Recaudacionsucursal[f] = sumatoriacantidades;
            System.out.println("sucursal " + (f + 1) + " = " + sumatoriacantidades);

        }

        // 5) • La recaudación total de cada sucursal.
        System.out.println("pregunta # 5");
        System.out.println(" La recaudación total de cada sucursal.");
        sumatoriacantidades = 0;

        for (int f = 0; f < recaudacion.length; f++) {

            for (int c = 0; c < recaudacion[0].length; c++) {
                sumatoriacantidades += recaudacion[f][c];

            }

        }
        System.out.println("RECAUDACION TOTAL total = " + sumatoriacantidades);

    }

}
