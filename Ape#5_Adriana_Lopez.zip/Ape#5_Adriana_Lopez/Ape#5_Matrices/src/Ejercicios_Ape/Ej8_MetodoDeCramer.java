package Ejercicios_Ape;

import java.util.Scanner;

public class Ej8_MetodoDeCramer {

    // Calcular el determinante de una matriz 2x2
    public static double determinante(double a, double b, double c, double d) {
        return a * d - b * c;
    }

    public static void main(String[] args) {
        // Crear un objeto Scanner para leer entradas
        Scanner teclado = new Scanner(System.in);

        // Introducción de las constantes de las ecuaciones
        System.out.println("Resuelve el sistema de ecuaciones lineales de dos incógnitas (Cramer):");
        System.out.println("Introduce el valor de a1 (coeficiente de x en la primera ecuación): ");
        double a1 = teclado.nextDouble();
        System.out.println("Introduce el valor de b1 (coeficiente de y en la primera ecuación): ");
        double b1 = teclado.nextDouble();
        System.out.println("Introduce el valor de c1 (el término independiente en la primera ecuación): ");
        double c1 = teclado.nextDouble();
        //Ecuacion dos 
        System.out.println("Introduce el valor de a2 (coeficiente de x en la segunda ecuación): ");
        double a2 = teclado.nextDouble();
        System.out.println("Introduce el valor de b2 (coeficiente de y en la segunda ecuación): ");
        double b2 = teclado.nextDouble();
        System.out.println("Introduce el valor de c2 (el término independiente en la segunda ecuación): ");
        double c2 = teclado.nextDouble();

        // Determinante principal (D)
        double D = determinante(a1, b1, a2, b2);

        // Si D es 0, el sistema no tiene solución única
        if (D == 0) {
            System.out.println("El sistema no tiene una solución única o tiene infinitas soluciones.");
        } else {
            // Determinantes Dx y Dy
            double Dx = determinante(c1, b1, c2, b2);
            double Dy = determinante(a1, c1, a2, c2);

            // Soluciones para x y y
            double x = Dx / D;
            double y = Dy / D;

            // Mostrar las soluciones
            System.out.println("La solución del sistema es:");
            System.out.println("x = " + x);
            System.out.println("y = " + y);
        }
    }
}