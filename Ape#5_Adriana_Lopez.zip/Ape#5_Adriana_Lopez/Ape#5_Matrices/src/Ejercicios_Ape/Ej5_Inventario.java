package Ejercicios_Ape;

public class Ej5_Inventario {
    // Precios de productos
    static int[] precios = { 100, 200, 50, 40, 80, 100, 60, 50 };

    // Matriz de stockproductos de productos en 3 almacenes (8 productos x 3 almacenes)
    static int[][] stockproductos = {
            { 10, 15, 20 }, // Producto 1
            { 5, 8, 10 }, // Producto 2
            { 12, 14, 18 }, // Producto 3
            { 30, 25, 28 }, // Producto 4
            { 7, 12, 14 }, // Producto 5
            { 9, 11, 10 }, // Producto 6
            { 6, 8, 5 }, // Producto 7
            { 20, 18, 25 } // Producto 8
    };

    // 1) Mostrar el inventario total de cada producto
    public static void mostrarInventarioTotal() {
        System.out.println("Inventario total de cada producto:");
        for (int i = 0; i < 8; i++) {
            int totalProducto = 0;
            for (int j = 0; j < 3; j++) {
                totalProducto += stockproductos[i][j];
            }
            System.out.println("Producto " + (i + 1) + ": " + totalProducto + " unidades.");
        }
    }

    // 2) Calcular el inventario total en el almacén 1
    public static void calcularInventarioAlmacen1() {
        int totalAlmacen1 = 0;
        for (int i = 0; i < 8; i++) {
            totalAlmacen1 += stockproductos[i][0];
        }
        System.out.println("\nInventario total en el almacén 1: " + totalAlmacen1 + " unidades.");
    }

    // 3) Mostrar el stockproductos del producto en el almacén específico
    public static void mostrarStockProductoEnAlmacen(int producto, int almacen) {
        // Aseguramos que las entradas son válidas
        if (producto > 0 && producto <= 8 && almacen > 0 && almacen <= 3) {
            System.out.println("\nStock del producto " + producto + " en el almacén " + almacen + ": "
                    + stockproductos[producto - 1][almacen - 1] + " unidades.");
        } else {
            System.out.println("\nProducto o almacén inválido.");
        }
    }

    // 4) Calcular el valor total del inventario de la cadena
    public static void calcularValorTotalInventario() {
        int valorTotalInventario = 0;
        for (int i = 0; i < 8; i++) {
            int totalProducto = 0;
            for (int j = 0; j < 3; j++) {
                totalProducto += stockproductos[i][j];
            }
            valorTotalInventario += totalProducto * precios[i];
        }
        System.out.println("\nValor total del inventario de la cadena: $" + valorTotalInventario);
    }

    // 5) Determinar el almacén con mayor cantidad de productos
    public static void determinarAlmacenConMayorStock() {
        int[] totalPorAlmacen = new int[3]; // Para almacenar el total de productos en cada almacén
        for (int j = 0; j < 3; j++) {
            for (int i = 0; i < 8; i++) {
                totalPorAlmacen[j] += stockproductos[i][j];
            }
        }

        int almacenMayorStock = 0;
        for (int j = 1; j < 3; j++) {
            if (totalPorAlmacen[j] > totalPorAlmacen[almacenMayorStock]) {
                almacenMayorStock = j;
            }
        }

        System.out.println("\nLa sucursal con mayor cantidad de productos es el almacén " + (almacenMayorStock + 1));
    }

    public static void main(String[] args) {
        mostrarInventarioTotal();
        calcularInventarioAlmacen1();
        mostrarStockProductoEnAlmacen(4, 2); // Producto 4, Almacén 2
        calcularValorTotalInventario();
        determinarAlmacenConMayorStock();
    }
}
