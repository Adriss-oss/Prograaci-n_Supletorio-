import java.util.Scanner;
import java.util.Calendar;
import java.text.DecimalFormat;
    public class M_Frances {
            public static void main(String[] args) {
                Scanner teclado = new Scanner(System.in);
                DecimalFormat df = new DecimalFormat("#,##0.00");
                int r=1;
                do{
                System.out.println("====================================================");
                System.out.println("                SIMULADOR DE CREDITO");
                System.out.println("====================================================");
                System.out.println("      ¿Qué tipo de crédito necesitas?        ");
                System.out.println("1) PRECISO");
                System.out.println("2) LINEA ABIERTA");
                System.out.println("3) HIPOTECARIO VIVIENDA");
                System.out.println("4) VIVIENDA DE INTERÉS PÚBLICO");
                System.out.println("5) VIVIENDA DE INTERÉS SOCIAL");
                System.out.println("6) EDUCACIÓN SUPERIOR");
                int oper = teclado.nextInt();
        
                String nombreCredito = "";
                double tasaAnual = 0;
                double porcentajeSeguro = 0.00429;
                double dinero = 0;
                int meses = 0;
        
                switch (oper) {
                    case 1:
                        nombreCredito = "PRECISO";
                        tasaAnual = 15.6;
                        System.out.print("¿Cuánto dinero necesitas (mínimo $300)? ");
                        dinero = teclado.nextDouble();
                        while (dinero < 300) {
                            System.out.println("Valor no permitido. Ingrese un valor mayor o igual a $300:");
                            dinero = teclado.nextDouble();
                        }
                        System.out.print("¿En cuántos meses deseas pagarlo (entre 3 y 240)? ");
                        meses = teclado.nextInt();
                        while (meses < 3 || meses > 240) {
                            System.out.println("Número de meses no válido. Ingrese entre 3 y 240:");
                            meses = teclado.nextInt();
                        }
                        break;
                    case 2:
                        nombreCredito = "LINEA ABIERTA";
                        tasaAnual = 13;
                        System.out.print("¿Cuánto dinero necesitas (mínimo $3000)? ");
                        dinero = teclado.nextDouble();
                        while (dinero < 3000) {
                            System.out.println("Valor no permitido. Ingrese un valor mayor o igual a $3000:");
                            dinero = teclado.nextDouble();
                        }
                        System.out.print("¿En cuántos meses deseas pagarlo (entre 3 y 240)? ");
                        meses = teclado.nextInt();
                        while (meses < 3 || meses > 240) {
                            System.out.println("Número de meses no válido. Ingrese entre 3 y 240:");
                            meses = teclado.nextInt();
                        }
                        break;
                    case 3:
                        nombreCredito = "HIPOTECARIO VIVIENDA";
                        tasaAnual = 10.93;
                        System.out.print("Ingrese el costo de la vivienda (mínimo $3000): ");
                        double costoHV = teclado.nextDouble();
                        while (costoHV < 3000) {
                            System.out.println("Valor no permitido. Ingrese un valor mayor o igual a $3000:");
                            costoHV = teclado.nextDouble();
                        }
                        System.out.print("¿Cuánto desea de crédito (mínimo $3000)? ");
                        dinero = teclado.nextDouble();
                        while (dinero < 3000 || dinero > costoHV) {
                            System.out.println("Valor no permitido. El crédito debe ser mayor a $3000 y menor o igual al costo de la vivienda:");
                            dinero = teclado.nextDouble();
                        }
                        System.out.print("¿En cuántos meses deseas pagarlo (entre 36 y 240)? ");
                        meses = teclado.nextInt();
                        while (meses < 36 || meses > 240) {
                            System.out.println("Número de meses no válido. Ingrese entre 36 y 240:");
                            meses = teclado.nextInt();
                        }
                        break;
                    case 4:
                        nombreCredito = "VIVIENDA DE INTERÉS PÚBLICO";
                        tasaAnual = 4.87;
                        System.out.print("Ingrese el costo de la vivienda (entre $83664.70 y $107630): ");
                        double costoVIP = teclado.nextDouble();
                        while (costoVIP < 83664.70 || costoVIP > 107630) {
                            System.out.println("Valor no permitido. Ingrese un valor entre $83664.70 y $107630:");
                            costoVIP = teclado.nextDouble();
                        }
                        System.out.print("¿Cuánto desea de crédito (mínimo $83664.70)? ");
                        dinero = teclado.nextDouble();
                        while (dinero < 83664.70 || dinero > costoVIP) {
                            System.out.println("Valor no permitido. El crédito debe ser mayor a $83664.70 y menor o igual al costo de la vivienda:");
                            dinero = teclado.nextDouble();
                        }
                        System.out.print("¿En cuántos meses deseas pagarlo (entre 240 y 300)? ");
                        meses = teclado.nextInt();
                        while (meses < 240 || meses > 300) {
                            System.out.println("Número de meses no válido. Ingrese entre 240 y 300:");
                            meses = teclado.nextInt();
                        }
                        break;
                    case 5:
                        nombreCredito = "VIVIENDA DE INTERÉS SOCIAL";
                        tasaAnual = 4.87;
                        System.out.print("Ingrese el costo de la vivienda (entre $27058 y $83660): ");
                        double costoVIS = teclado.nextDouble();
                        while (costoVIS < 27058 || costoVIS > 83660) {
                            System.out.println("Valor no permitido. Ingrese un valor entre $27058 y $83660:");
                            costoVIS = teclado.nextDouble();
                        }
                        System.out.print("¿Cuánto desea de crédito (mínimo $27058)? ");
                        dinero = teclado.nextDouble();
                        while (dinero < 27058 || dinero > costoVIS) {
                            System.out.println("Valor no permitido. El crédito debe ser mayor a $27058 y menor o igual al costo de la vivienda:");
                            dinero = teclado.nextDouble();
                        }
                        System.out.print("¿En cuántos meses deseas pagarlo (entre 240 y 300)? ");
                        meses = teclado.nextInt();
                        while (meses < 240 || meses > 300) {
                            System.out.println("Número de meses no válido. Ingrese entre 240 y 300:");
                            meses = teclado.nextInt();
                        }
                        break;
                    case 6:
                        nombreCredito = "EDUCACIÓN SUPERIOR";
                        tasaAnual = 9;
                        System.out.print("¿Cuánto dinero necesitas (entre $500 y $150000)? ");
                        dinero = teclado.nextDouble();
                        while (dinero < 500 || dinero > 150000) {
                            System.out.println("Valor no permitido. Ingrese un valor entre $500 y $150000:");
                            dinero = teclado.nextDouble();
                        }
                        System.out.print("¿En cuántos meses deseas pagarlo (entre 6 y 126)? ");
                        meses = teclado.nextInt();
                        while (meses < 6 || meses > 126) {
                            System.out.println("Número de meses no válido. Ingrese entre 6 y 126:");
                            meses = teclado.nextInt();
                        }
                        break;
                    default:
                        System.out.println("Opción no válida.");
                        teclado.close();
                        return;
                }
        
                double tasaMensual = tasaAnual / 12 / 100;
                double cuota = dinero * (tasaMensual / (1 - Math.pow(1 + tasaMensual, -meses)));
                double saldo = dinero;
                double totalInteres = 0;
                double totalDesgravamen = 0;

                System.out.println("====================================================");
                System.out.println("\n             TABLA DE AMORTIZACIÓN                ");
                System.out.println("====================================================");
                System.out.println("Producto: " + nombreCredito);
                System.out.println("Plazo (meses): " + meses);
                System.out.println("Tasa de interés nominal: " + tasaAnual + "%");
                System.out.println("Tasa de interés efectiva anual: " + df.format((Math.pow(1 + tasaMensual, 12) - 1) * 100) + "%\n");
        
                System.out.printf("%-8s %-15s %-12s %-12s %-15s %-12s %-12s\n",
                        "Cuota", "Fecha de pago", "Capital", "Interés", "Seguros des.", "Valor cuota", "Saldo");
        
                        Calendar fecha = Calendar.getInstance();
                        fecha.set(2025, Calendar.MAY, 31);
        
                for (int i = 1; i <= meses; i++) {
                    double interes = saldo * tasaMensual;
                    double capital = cuota - interes;
                    double seguroDesg = capital * porcentajeSeguro;
                    totalInteres += interes;
                    totalDesgravamen += seguroDesg;
                    saldo -= capital;
                    saldo = Math.max(0, saldo);
        
                    System.out.printf("%-8d %-15s $%-11s $%-11s $%-14s $%-11s $%-11s\n",
                            i,
                            String.format("%1$tY-%1$tm-%1$td", fecha.getTime()),
                            String.format("%,.2f", capital),
                            String.format("%,.2f", interes),
                            String.format("%,.2f", seguroDesg),
                            String.format("%,.2f", cuota),
                            String.format("%,.2f", saldo));
        
                        fecha.add(Calendar.MONTH, 1);
                }
                System.out.println("\nTotal de interés: $" + df.format(totalInteres));
                System.out.println("Total seguro de desgravamen: $" + df.format(totalDesgravamen));
                
                    System.out.println("====================================================================");
                    System.out.println("Ingrese (1) si desea repetir el proceso de lo contario ingrese (0)");
                    System.out.println("====================================================================");
                    r=teclado.nextInt();
                
                }while(r!=0  );
                 System.out.println("****************** Gracias por confiar en nuestro servicio ******************");
                teclado.close();
            }
        }
        