import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class App {
    private static final String ruta = "C:\\Users\\Adriana\\Documentos\\ProductosExportacion.csv";

    public static class Productos {
        private String mes, año, pais, tipoproducto;
        private int id;
        private int pesotoneladas;
        private double montomillones;

        public void setId(int id) { this.id = id; }
        public int getId() { return id; }

        public void setMes(String mes) { this.mes = mes; }
        public String getMes() { return mes; }

        public void setAño(String año) { this.año = año; }
        public String getAño() { return año; }

        public void setPais(String pais) { this.pais = pais; }
        public String getPais() { return pais; }

        public void setTipoproducto(String tipoproducto) { this.tipoproducto = tipoproducto; }
        public String getTipoproducto() { return tipoproducto; }

        public void setPesotoneladas(int pesotoneladas) { this.pesotoneladas = pesotoneladas; }
        public int getPesotoneladas() { return pesotoneladas; }

        public void setMontomillones(double montomillones) { this.montomillones = montomillones; }
        public double getMontomillones() { return montomillones; }

        @Override
        public String toString() {
            return id + " | " + mes + " | " + año + " | " + pais + " | " + tipoproducto + " | " +
                   pesotoneladas + "t | $" + montomillones + "M";
        }

        public static void guardarCSV(ArrayList<Productos> listaProductos) throws IOException {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(ruta))) {
                writer.write("id,mes,año,pais,tipoProducto,pesoToneladas,montoMillonesDolares\n");
                for (Productos p : listaProductos) {
                    writer.write(p.getId() + "," + p.getMes() + "," + p.getAño() + "," +
                                 p.getPais() + "," + p.getTipoproducto() + "," +
                                 p.getPesotoneladas() + "," + p.getMontomillones() + "\n");
                }
            }
        }
    }

    public static String paisNorteamericaMasExporta(ArrayList<Productos> lista) {
        String[] paisesNA = {"Estados Unidos", "Canada", "México"};
        Map<String, Integer> sumaPesos = new HashMap<>();
        for (String pais : paisesNA) {
            sumaPesos.put(pais, 0);
        }

        for (Productos p : lista) {
            String pais = p.getPais().trim();
            if (pais.equalsIgnoreCase("Estados Unidos") || pais.equalsIgnoreCase("USA") || pais.equalsIgnoreCase("United States")) {
                pais = "Estados Unidos";
            } else if (pais.equalsIgnoreCase("Canada") || pais.equalsIgnoreCase("Canadá")) {
                pais = "Canada";
            } else if (pais.equalsIgnoreCase("México") || pais.equalsIgnoreCase("Mexico")) {
                pais = "México";
            }

            if (sumaPesos.containsKey(pais)) {
                sumaPesos.put(pais, sumaPesos.get(pais) + p.getPesotoneladas());
            }
        }

        String maxPais = null;
        int maxPeso = -1;
        for (Map.Entry<String, Integer> entry : sumaPesos.entrySet()) {
            if (entry.getValue() > maxPeso) {
                maxPeso = entry.getValue();
                maxPais = entry.getKey();
            }
        }
        return maxPais;
    }

    public static void resumenExportacionesPorAño(ArrayList<Productos> lista) {
        Map<String, Integer> cantidadPorAño = new HashMap<>();
        Map<String, Double> montoPorAño = new HashMap<>();

        for (Productos p : lista) {
            String año = p.getAño();
            cantidadPorAño.put(año, cantidadPorAño.getOrDefault(año, 0) + 1);
            montoPorAño.put(año, montoPorAño.getOrDefault(año, 0.0) + p.getMontomillones());
        }

        System.out.println("\nResumen de exportaciones por año:");
        for (String año : cantidadPorAño.keySet()) {
            int cantidad = cantidadPorAño.get(año);
            double monto = montoPorAño.get(año);
            System.out.println("Año: " + año + " | Productos exportados: " + cantidad + " | Monto total: $" + monto + "M");
        }
    }

    public static void analisisSemestralYPeso(ArrayList<Productos> lista) {
        int[] añosAnalizar = {2022, 2023, 2024};

        for (int añoActual : añosAnalizar) {
            double monto1S = 0.0, monto2S = 0.0;
            int pesoTotal = 0, cantidadProductos = 0;

            for (Productos p : lista) {
                if (Integer.parseInt(p.getAño()) == añoActual) {
                    int mesNumero = mesAEntero(p.getMes().toLowerCase());
                    if (mesNumero == -1) continue;

                    if (mesNumero >= 1 && mesNumero <= 6) {
                        monto1S += p.getMontomillones();
                    } else if (mesNumero >= 7 && mesNumero <= 12) {
                        monto2S += p.getMontomillones();
                    }
                    pesoTotal += p.getPesotoneladas();
                    cantidadProductos++;
                }
            }

            double totalMonto = monto1S + monto2S;
            System.out.println("\nAnálisis para el año " + añoActual + ":");

            if (totalMonto > 0) {
                double porcentaje1S = (monto1S / totalMonto) * 100;
                double porcentaje2S = (monto2S / totalMonto) * 100;
                System.out.printf("Porcentaje de monto primer semestre: %.2f%%\n", porcentaje1S);
                System.out.printf("Porcentaje de monto segundo semestre: %.2f%%\n", porcentaje2S);
            } else {
                System.out.println("No hay datos de montos para este año.");
            }

            if (cantidadProductos > 0) {
                double promedioPeso = (double) pesoTotal / cantidadProductos;
                System.out.printf("Promedio de peso por producto: %.2f toneladas\n", promedioPeso);
            } else {
                System.out.println("No hay productos registrados para este año.");
            }
        }
    }

    public static int mesAEntero(String mes) {
        switch (mes.toLowerCase()) {
            case "enero": return 1;
            case "febrero": return 2;
            case "marzo": return 3;
            case "abril": return 4;
            case "mayo": return 5;
            case "junio": return 6;
            case "julio": return 7;
            case "agosto": return 8;
            case "septiembre": return 9;
            case "octubre": return 10;
            case "noviembre": return 11;
            case "diciembre": return 12;
            default: return -1;
        }
    }

    public static void main(String[] args) throws Exception {
        ArrayList<Productos> listaProductos = new ArrayList<>();

        try (BufferedReader leerarchivo = new BufferedReader(new FileReader(ruta))) {
            String linea;
            boolean encabezado = true;
            while ((linea = leerarchivo.readLine()) != null) {
                if (encabezado) {
                    encabezado = false;
                    continue;
                }
                String[] datos = linea.split(",");
                if (datos.length == 7) {
                    Productos p = new Productos();
                    p.setId(Integer.parseInt(datos[0].trim()));
                    p.setMes(datos[1].trim());
                    p.setAño(datos[2].trim());
                    p.setPais(datos[3].trim());
                    p.setTipoproducto(datos[4].trim());
                    p.setPesotoneladas(Integer.parseInt(datos[5].trim()));
                    p.setMontomillones(Double.parseDouble(datos[6].trim()));
                    listaProductos.add(p);
                }
            }
        } catch (Exception e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }

        System.out.println("\nProductos cargados:");
        for (Productos p : listaProductos) {
            System.out.println(p);
        }

        Scanner sc = new Scanner(System.in);
        System.out.print("\n¿Deseas ingresar nuevos productos? (si/no): ");
        String respuesta = sc.nextLine().trim();

        while (respuesta.equalsIgnoreCase("si") || respuesta.equalsIgnoreCase("sí")) {
            Productos nuevo = new Productos();

            System.out.print("ID: ");
            nuevo.setId(Integer.parseInt(sc.nextLine()));

            System.out.print("Mes: ");
            nuevo.setMes(sc.nextLine());

            System.out.print("Año: ");
            nuevo.setAño(sc.nextLine());

            System.out.print("País: ");
            nuevo.setPais(sc.nextLine());

            System.out.print("Tipo de producto: ");
            nuevo.setTipoproducto(sc.nextLine());

            System.out.print("Peso en toneladas: ");
            nuevo.setPesotoneladas(Integer.parseInt(sc.nextLine()));

            System.out.print("Monto en millones de dólares: ");
            nuevo.setMontomillones(Double.parseDouble(sc.nextLine()));

            listaProductos.add(nuevo);

            System.out.print("\n¿Ingresar otro producto? (si/no): ");
            respuesta = sc.nextLine().trim();
        }

        sc.close();

        if (!listaProductos.isEmpty()) {
            Productos.guardarCSV(listaProductos);
            System.out.println("\nDatos guardados correctamente en el archivo.");
        }

        String paisMax = paisNorteamericaMasExporta(listaProductos);
        if (paisMax != null) {
            System.out.println("\nPaís de Norteamérica con más exportaciones: " + paisMax);
        } else {
            System.out.println("\nNo se encontraron exportaciones de países de Norteamérica.");
        }

        resumenExportacionesPorAño(listaProductos);
        analisisSemestralYPeso(listaProductos);
    }
}
