import java.util.LinkedList;
import java.util.Random;

public class App {

    public static void main(String[] args) throws Exception {
        
        LinkedList<lista> = extracted();

        String ruta="EVALUACIPO-2_ADRIANA_LÓPEZ/src/Articulos.csv";
        
    }

    private static LinkedList<lista> extracted() {
        return new LinkedList<>();
    }
    Random ramdom_ = new Random();

    public static void CargarLasCantidadesVendidas(int cant_vendidas[][], String vendedor[][]){
        for (int i = 0; i < vendedor.length; i++) {
            vendedor[i][j]=ramdom_;
            for (int j = 0; j < cant_vendidas.length; j++) {
                cant_vendidas[i][j]=random_(1,20);
                System.out.println();
                System.out.println(cant_vendidas[i][j]);
            } 
        }
    }

    public static void CantidadDineroRecopílado(){
        String vendedor_A,vendedor_B,vendedor_C,vendedor_D,vendedor_E;


    }
    //#5
    public static void Promedio(){

    }
    //#6
    public static void CalcularLaDesviacionEstandar(){

    }



    

}
