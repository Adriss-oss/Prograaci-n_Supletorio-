public class NumerosAmigos {

}
