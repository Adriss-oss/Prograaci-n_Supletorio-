public class NumeroPerteneceABase {

}
