public class PrimosEnRango {

}
