public class DigitoMayor {

}
