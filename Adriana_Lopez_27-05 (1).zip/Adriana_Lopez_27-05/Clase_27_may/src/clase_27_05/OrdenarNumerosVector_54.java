package clase_27_05;
import java.util.Arrays;
import java.util.Scanner;

public class OrdenarNumerosVector_54 {
// Ejercicio_54 capitulo 7
    public static int[] leerNumeros() {
        Scanner scanner = new Scanner(System.in);
        int[] numeros = new int[5];

        System.out.println("Ingrese 5 números:");
        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

        return numeros;
    }

    public static void ordenarAscendente(int[] vector) {
        Arrays.sort(vector);
    }

    public static void ordenarDescendente(int[] vector) {
        Arrays.sort(vector);

        for (int i = 0; i < vector.length / 2; i++) {
            int temp = vector[i];
            vector[i] = vector[vector.length - 1 - i];
            vector[vector.length - 1 - i] = temp;
        }
    }

    public static void mostrarVector(int[] vector) {
        System.out.print("Números ordenados: ");
        for (int num : vector) {
            System.out.print(num + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] numeros = leerNumeros();

        System.out.print("¿Cómo desea ordenar los números? (A = Ascendente, D = Descendente): ");
        char opcion = scanner.next().toUpperCase().charAt(0);

        if (opcion == 'A') {
            ordenarAscendente(numeros);
        } else if (opcion == 'D') {
            ordenarDescendente(numeros);
        } else {
            System.out.println("Opción inválida. Se mostrará el vector sin ordenar.");
        }

        mostrarVector(numeros);
    }
}

