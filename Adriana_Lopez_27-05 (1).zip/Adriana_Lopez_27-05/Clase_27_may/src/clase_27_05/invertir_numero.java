package clase_27_05;

import java.util.Scanner;

public class invertir_numero {
    private Scanner teclado;
    private int numero,digito,invetido;
    //Ejercicio 78
    public  void Ingresardatos(){
        teclado = new Scanner(System.in);
        System.out.println("Ingresar el numero a invertir ");
        numero=teclado.nextInt();
    }
    public int invertirNumero() {
        int invertido = 0;
        while (numero != 0) {
            int digito = numero % 10;
            invertido = invertido * 10 + digito;
            numero /= 10;
        }
        System.out.println("El numero invertido es: "+invertido);
        return invertido;
    }

    public static void main(String[] args) {
        invertir_numero invertido_ =new invertir_numero();
        invertido_.Ingresardatos();
        invertido_.invertirNumero();

        
    }
}

