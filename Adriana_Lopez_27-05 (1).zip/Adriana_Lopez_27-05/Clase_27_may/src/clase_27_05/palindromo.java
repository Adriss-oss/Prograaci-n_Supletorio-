package clase_27_05;
import java.util.Scanner;

public class palindromo {
    //Ejercicio 79

        public void Verificarsilapalabraespalindromo(String palabra) {
             String limpia = palabra.replaceAll("\\s+", "").toLowerCase();
        String invertida = new StringBuilder(limpia).reverse().toString();

        if (limpia.equals(invertida)) {
            System.out.println("La palabra \"" + palabra + "\" ES un palíndromo.");
        } else {
            System.out.println("La palabra \"" + palabra + "\" NO es un palíndromo.");
        }
        }
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        palindromo verificador = new palindromo();
        String repetir;

        do {
            System.out.println("Ingrese una palabra: ");
            String palabra = teclado.nextLine();
            verificador.Verificarsilapalabraespalindromo(palabra);
            System.out.println("desea realizar de nuevo s=si o n=no");
            repetir = teclado.nextLine().toLowerCase();
            System.out.println();

        } while (repetir.equals("s"));
       System.out.println("------------------EL PROGRAMA FINALIZO-----------");
    }
}





