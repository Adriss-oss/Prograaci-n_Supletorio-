package clase_27_05;
import java.util.Scanner;

public class NumerosrepetidosVector_55 {

    
    public static int[] leerNumeros() {
        Scanner scanner = new Scanner(System.in);
        int[] numeros = new int[6];

        System.out.println("Ingrese 6 números:");
        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

        return numeros;
    }

    public static int contarRepetidos(int[] vector) {
        boolean[] yaContado = new boolean[vector.length];
        int repetidos = 0;

        for (int i = 0; i < vector.length; i++) {
            if (yaContado[i]) continue;

            boolean esRepetido = false;
            for (int j = i + 1; j < vector.length; j++) {
                if (vector[i] == vector[j]) {
                    yaContado[j] = true;
                    esRepetido = true;
                }
            }

            if (esRepetido) {
                repetidos++;
            }
        }

        return repetidos;
    }

    public static void main(String[] args) {
        int[] numeros = leerNumeros();
        int cantidadRepetidos = contarRepetidos(numeros);

        System.out.println("\nCantidad de números repetidos: " + cantidadRepetidos);
    }
}

