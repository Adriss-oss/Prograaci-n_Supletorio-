package clase_27_05;
import java.util.Scanner;
//Ejercicio 71
public class Area_perimetro {
    
    private double lado;
    private Scanner teclado;

    public void ingresarLado() {
        teclado = new Scanner(System.in);
        System.out.print("Ingrese la longitud del lado del cuadrado: ");
        lado = teclado.nextDouble();
    }

    public void calcularAreaYPerimetro() {
        double area = lado * lado;
        double perimetro = 4 * lado;

        System.out.println("El área del cuadrado es: " + area);
        System.out.println("El perímetro del cuadrado es: " + perimetro);
    }

    public static void main(String[] args) {
        Area_perimetro cuadrado = new Area_perimetro();
        cuadrado.ingresarLado();
        cuadrado.calcularAreaYPerimetro();
    }
}


