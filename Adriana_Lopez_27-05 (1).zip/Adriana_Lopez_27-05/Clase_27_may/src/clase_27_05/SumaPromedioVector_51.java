package clase_27_05;
import java.util.Scanner;

public class SumaPromedioVector_51 {
// Ejercicio_51 capitulo 7
    public static int[] leerNumeros() {
        Scanner scanner = new Scanner(System.in);
        int[] numeros = new int[4];

        System.out.println("Ingrese 4 números:");
        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

        return numeros;
    }

    
    public static int calcularSuma(int[] vector) {
        int suma = 0;
        for (int num : vector) {
            suma += num;
        }
        return suma;
    }

    public static double calcularPromedio(int suma, int cantidad) {
        return (double) suma / cantidad;
    }

    public static void main(String[] args) {
        int[] numeros = leerNumeros();
        int suma = calcularSuma(numeros);
        double promedio = calcularPromedio(suma, numeros.length);

        System.out.println("Suma: " + suma);
        System.out.println("Promedio: " + promedio);
    }
}
