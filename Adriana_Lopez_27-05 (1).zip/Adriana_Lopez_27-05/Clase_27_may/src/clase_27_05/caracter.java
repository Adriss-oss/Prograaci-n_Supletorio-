package clase_27_05;
import java.util.Scanner;

//Ejercicio 75
public class caracter {
    

    private char caracter;

    public void ingresarCaracter() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese un carácter: ");
        String input = scanner.nextLine();

        // Validar que se ingrese solo un carácter
        while (input.length() != 1) {
            System.out.print("Error. Ingrese un solo carácter: ");
            input = scanner.nextLine();
        }
        caracter = input.charAt(0);
    }

    public void clasificarCaracter() {
        if (esVocal(caracter)) {
            System.out.println("El carácter es una vocal.");
        } else if (Character.isUpperCase(caracter)) {
            System.out.println("El carácter es una letra mayúscula.");
        } else if (Character.isLowerCase(caracter)) {
            System.out.println("El carácter es una letra minúscula.");
        } else if (Character.isDigit(caracter)) {
            System.out.println("El carácter es un número.");
        } else {
            System.out.println("El carácter es un símbolo.");
        }
    }

    private boolean esVocal(char c) {
        // Convertimos a minúscula para simplificar la comparación
        char ch = Character.toLowerCase(c);
        return (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u');
    }

    public static void main(String[] args) {
        caracter programa = new caracter();
        programa.ingresarCaracter();
        programa.clasificarCaracter();
    }
}

