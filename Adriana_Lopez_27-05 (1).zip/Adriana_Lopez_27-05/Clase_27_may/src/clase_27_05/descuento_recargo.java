package clase_27_05;

import java.util.Scanner;

public class descuento_recargo {
//Ejercicio 77
    public static double obtenerRecargo(char tipo) {
        if (tipo == 'G') return 0.10;
        else if (tipo == 'A') return 0.05;
        return 0;
    }

    public static double obtenerDescuento(char tipo) {
        if (tipo == 'G') return 0.05;
        else if (tipo == 'A') return 0.10;
        return 0;
    }

    public static double calcularTotal(double monto, char tipoCliente, char formaPago) {
        if (formaPago == 'C') {
            double desc = monto * obtenerDescuento(tipoCliente);
            return monto - desc;
        } else if (formaPago == 'P') {
            double rec = monto * obtenerRecargo(tipoCliente);  // aquí estaba el error
            return monto + rec;
        }
        return monto; // forma de pago inválida
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese el monto de la compra: ");
        double monto = sc.nextDouble();
        sc.nextLine(); // limpiar el buffer

        System.out.print("Ingrese el tipo de cliente (G = general, A = afiliado): ");
        char tipoCliente = sc.nextLine().toUpperCase().charAt(0);

        System.out.print("Ingrese la forma de pago (C = contado, P = plazos): ");
        char formaPago = sc.nextLine().toUpperCase().charAt(0);

        double total = calcularTotal(monto, tipoCliente, formaPago);
        System.out.println("Total a pagar: " + total);
    }
}
