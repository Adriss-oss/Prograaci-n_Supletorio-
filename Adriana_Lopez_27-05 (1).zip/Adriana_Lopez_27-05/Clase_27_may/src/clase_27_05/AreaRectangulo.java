package clase_27_05;
import java.util.Scanner;

public class AreaRectangulo {

    // Función para calcular el área
    public static double calcularArea(double base, double altura) {
        return base * altura;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Ingrese la base del rectángulo: ");
        double base = teclado.nextDouble();

        System.out.print("Ingrese la altura del rectángulo: ");
        double altura = teclado.nextDouble();

        double area = calcularArea(base, altura);
        System.out.println("El área del rectángulo es: " + area);
    }
}


