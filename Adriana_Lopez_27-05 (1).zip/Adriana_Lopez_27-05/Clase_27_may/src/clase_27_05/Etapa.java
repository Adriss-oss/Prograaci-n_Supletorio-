package clase_27_05;
    import java.util.Scanner;
//Ejercicio 73
public class Etapa {

    private int edad;

    public void ingresarEdad() {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Ingrese la edad de la persona: ");
        edad = teclado.nextInt();
    }

    public void determinarEtapa() {
        if (edad < 0) {
            System.out.println("Edad no válida. Debe ser un número positivo.");
        } else if (edad <= 12) {
            System.out.println("Etapa de la vida: Niñez");
        } else if (edad <= 17) {
            System.out.println("Etapa de la vida: Adolescencia");
        } else if (edad <= 59) {
            System.out.println("Etapa de la vida: Adultez");
        } else {
            System.out.println("Etapa de la vida: Vejez");
        }
    }

    public static void main(String[] args) {
        Etapa persona = new Etapa();
        persona.ingresarEdad();
        persona.determinarEtapa();
    }
}



