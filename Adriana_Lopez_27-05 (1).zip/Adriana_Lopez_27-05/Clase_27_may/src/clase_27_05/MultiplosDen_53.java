package clase_27_05;
import java.util.Scanner;

public class MultiplosDen_53 {
// Ejercicio_53 capitulo 7
    public static int[] leerNumeros() {
        Scanner scanner = new Scanner(System.in);
        int[] numeros = new int[6];

        System.out.println("Ingrese 6 números:");
        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

        return numeros;
    }

    
    public static int contarMultiplos(int[] vector, int n) {
        int contador = 0;
        for (int num : vector) {
            if (num % n == 0) {
                contador++;
            }
        }
        return contador;
    }

       public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] numeros = leerNumeros();

        System.out.print("Ingrese el número n para verificar múltiplos: ");
        int n = scanner.nextInt();

        int cantidadMultiplos = contarMultiplos(numeros, n);

        System.out.println("\nCantidad de múltiplos de " + n + ": " + cantidadMultiplos);
    }
}

