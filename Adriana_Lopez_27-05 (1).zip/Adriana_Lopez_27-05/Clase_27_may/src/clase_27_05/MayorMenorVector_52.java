package clase_27_05;

import java.util.Scanner;

public class MayorMenorVector_52 {
// Ejercicio_52 capitulo 7
    
    public static int[] leerNumeros() {
        Scanner scanner = new Scanner(System.in);
        int[] numeros = new int[4];

        System.out.println("Ingrese 4 números:");
        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

        return numeros;
    }

    
    public static int encontrarMayor(int[] vector) {
        int mayor = vector[0];
        for (int i = 1; i < vector.length; i++) {
            if (vector[i] > mayor) {
                mayor = vector[i];
            }
        }
        return mayor;
    }

    
    public static int encontrarMenor(int[] vector) {
        int menor = vector[0];
        for (int i = 1; i < vector.length; i++) {
            if (vector[i] < menor) {
                menor = vector[i];
            }
        }
        return menor;
    }

    public static void main(String[] args) {
        int[] numeros = leerNumeros();

        int mayor = encontrarMayor(numeros);
        int menor = encontrarMenor(numeros);

        
        int[] resultado = new int[2];
        resultado[0] = mayor;
        resultado[1] = menor;

        System.out.println("\nNúmero mayor: " + resultado[0]);
        System.out.println("Número menor: " + resultado[1]);
    }
}
