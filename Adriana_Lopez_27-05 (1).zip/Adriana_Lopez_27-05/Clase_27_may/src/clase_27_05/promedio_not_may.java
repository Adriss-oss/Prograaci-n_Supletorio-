package clase_27_05;
import java.util.Scanner;
//ejercicio 72
public class promedio_not_may {

        private double nota1, nota2, nota3;
    
        public void ingresarNotas() {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Ingrese la primera nota: ");
            nota1 = scanner.nextDouble();
    
            System.out.print("Ingrese la segunda nota: ");
            nota2 = scanner.nextDouble();
    
            System.out.print("Ingrese la tercera nota: ");
            nota3 = scanner.nextDouble();
        }
    
        public void calcularPromedioDosMayores() {
            double menor;
    
            // nota menor
            if (nota1 <= nota2 && nota1 <= nota3) {
                menor = nota1;
            } else if (nota2 <= nota1 && nota2 <= nota3) {
                menor = nota2;
            } else {
                menor = nota3;
            }
    
            // Suma total menos la nota menor da la suma de las dos mayores
            double sumaDosMayores = (nota1 + nota2 + nota3) - menor;
    
            // Promedio de las dos notas mayores
            double promedio = sumaDosMayores / 2.0;
    
            System.out.println("El promedio de las dos notas mayores es: " + promedio);
        }
    
        public static void main(String[] args) {
            promedio_not_may promedioNotas = new  promedio_not_may();
    
            promedioNotas.ingresarNotas();
            promedioNotas.calcularPromedioDosMayores();
        }
}
    

