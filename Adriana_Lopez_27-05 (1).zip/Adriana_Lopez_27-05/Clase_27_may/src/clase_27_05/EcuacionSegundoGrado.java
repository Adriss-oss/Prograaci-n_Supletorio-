package clase_27_05;

import java.util.Scanner;

public class EcuacionSegundoGrado {
    private Scanner teclado;
    private int a, b, c;
    private double discriminante;
    private double x1, x2, x0;

    public void ingresarDatosDeEcuacion() {
        teclado = new Scanner(System.in);
        System.out.println("Ecuación de segundo grado:");
        System.out.println("Forma general: ax² + bx + c = 0");
        System.out.println("----------------------------------");

        System.out.print("Ingresar el valor de a (coeficiente de x²): ");
        a = teclado.nextInt();

        System.out.print("Ingresar el valor de b (coeficiente de x): ");
        b = teclado.nextInt();

        System.out.print("Ingresar el valor de c (término independiente): ");
        c = teclado.nextInt();

        System.out.println("La ecuación ingresada es:");
        System.out.println(a + "x² + " + b + "x + " + c + " = 0");
    }

    public void calcularDiscriminante() {
        discriminante = Math.pow(b, 2) - 4 * a * c;
        System.out.println("El valor del discriminante es: " + discriminante);
    }

    public void calcularUsandoFormulaGeneral() {
        if (discriminante > 0) {
            System.out.println("Existen dos soluciones reales distintas:");
            System.out.println("Usamos la fórmula general:");
            System.out.println("x = (-b ± √(b² - 4ac)) / (2a)");

            x1 = (-b + Math.sqrt(discriminante)) / (2.0 * a);
            x2 = (-b - Math.sqrt(discriminante)) / (2.0 * a);

            System.out.println("El valor de x1 es: " + x1);
            System.out.println("El valor de x2 es: " + x2);
        } else if (discriminante == 0) {
            System.out.println("La ecuación tiene una única solución real:");
            x0 = -b / (2.0 * a);
            System.out.println("El valor de x es: " + x0);
        } else {
            System.out.println("La ecuación no tiene soluciones reales (las soluciones son complejas).");
        }
    }

    public static void main(String[] args) {
        EcuacionSegundoGrado ecuacion = new EcuacionSegundoGrado();

        ecuacion.ingresarDatosDeEcuacion();
        ecuacion.calcularDiscriminante();
        ecuacion.calcularUsandoFormulaGeneral();
    }
}
