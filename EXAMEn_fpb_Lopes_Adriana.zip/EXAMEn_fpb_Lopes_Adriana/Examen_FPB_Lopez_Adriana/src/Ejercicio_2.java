import java.util.Scanner;

public class Ejercicio_2 {
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        int n_inicial,n_final,sum=0,res;
        System.out.println("Ingresar el numero inicial");
        n_inicial=teclado.nextInt();
        System.out.println("Ingresar el numero Final");
        n_final=teclado.nextInt();
        for (int i = n_inicial; i < n_final; i++) {
            res=i%2;
            if (res!=0) {
                System.out.println(i);
                sum=sum+i;
            } 
        }
        System.out.println("------------------------------------");
        System.out.println("La sumatoria de los numeros impares,no primos es: "+sum);
    }

}
