import java.util.Scanner;

public class Ejercicio_1 {
    public static void main(String[] args) throws Exception {
        Scanner teclado = new Scanner(System.in);
            int km1=0,km2=0,encuentro=0;
           
            System.out.println("Ingresar el km en elcual se encuentra la persona que se dirige hacia Ambato ");
            km1=teclado.nextInt();
            System.out.println("Ingresar el km en elcual se encuentra la persona que se dirige hacia Quito ");
            km2=teclado.nextInt();
            if (km1==km2) {
                System.out.println("las dos personas se encuentran en la mitad del camino");
                
            }
            while (km2>km1 || km1>km2) {
                if (km2>km1) {
                    encuentro=km2-km1;
                   
                }else{
                    encuentro=km1-km2;
                }
                int resp=encuentro/2;
                System.out.println("El km en el cual se encontraran es:"+resp);
                break;
            }
               
    }
}
