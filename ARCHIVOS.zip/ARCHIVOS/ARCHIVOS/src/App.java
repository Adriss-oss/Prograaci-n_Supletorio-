import java.io.BufferedReader;
import java.io.FileReader;
import java.util.LinkedList;

public class App {
    public static void main(String[] args) throws Exception {
        
        String ruta="src/DelitosProvincia.csv";
        try(BufferedReader reader = new BufferedReader(new FileReader(ruta))) {
            String linea;
            LinkedList<Delito> listadelito = new LinkedList<>();
            boolean cabecera=true;
            //Linkedlist

            while ((linea = reader.readLine())!) {
                
            }
            
        } catch (Exception e) {
            // TODO: handle exception
        }
    }
}
