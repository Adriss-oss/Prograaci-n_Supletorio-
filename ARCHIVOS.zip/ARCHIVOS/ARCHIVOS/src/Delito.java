public class Delito {
    private String provincia;
    private String delito;
    private String judicializado;
    private String victima;

    public Delito(String provincia, String delito, String judicializado, String victima) {
        this.provincia = provincia;
        this.delito = delito;
        this.judicializado = judicializado;
        this.victima = victima;

 
        public String getProvincia() {
        return provincia;
        }

       public void setVictima(String victima) {
       this.victima = victima;
       }

       public String getJudicializado() {
        return judicializado;
      }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return super.toString();
    }

        
    }

}

