import java.util.Scanner;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
public class M_Aleman {
        public static void main(String[] args) {
            Scanner teclado = new Scanner(System.in);
            DecimalFormat df = new DecimalFormat("#,##0.00");
            DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            int r=1;
            do{
            System.out.println("====================================================");
            System.out.println("                SIMULADOR DE CREDITO");
            System.out.println("====================================================");
            System.out.println("      ¿Qué tipo de crédito necesitas?        ");
            System.out.println("1) PRECISO");
            System.out.println("2) LINEA ABIERTA");
            System.out.println("3) HIPOTECARIO VIVIENDA");
            System.out.println("4) VIVIENDA DE INTERÉS PÚBLICO");
            System.out.println("5) VIVIENDA DE INTERÉS SOCIAL");
            System.out.println("6) EDUCACIÓN SUPERIOR");
            int oper = teclado.nextInt();
    
            String nombreCredito = "";
            double tasaAnual = 0;
            double porcentajeSeguro = 0.00429; // 0.429%
            int minMonto = 0;
            double costoVivienda = 0;
    
            switch (oper) {
                case 1:
                    nombreCredito = "PRECISO";
                    tasaAnual = 15.6;
                    minMonto = 300;
                    break;
                case 2:
                    nombreCredito = "LINEA ABIERTA";
                    tasaAnual = 13;
                    minMonto = 3000;
                    break;
                case 3:
                    nombreCredito = "HIPOTECARIO VIVIENDA";
                    tasaAnual = 10.93;
                    minMonto = 3000;
                    System.out.println("---------CRÉDITO " + nombreCredito + "---------");
                    System.out.println("¿Cuál es el valor de la vivienda? (mínimo $" + minMonto + "):");
                    costoVivienda = teclado.nextDouble();
                    while (costoVivienda < minMonto) {
                        System.out.println("Valor no permitido. Ingrese un valor mayor o igual a $" + minMonto + ":");
                        costoVivienda = teclado.nextDouble();
                    }
                    break;
                case 4:
                    nombreCredito = "VIVIENDA DE INTERÉS PÚBLICO";
                    tasaAnual = 4.87;
                    minMonto = 83664;
                    System.out.println("---------CRÉDITO " + nombreCredito + "---------");
                    System.out.println("¿Cuál es el valor de la vivienda? (mínimo $" + minMonto + "):");
                    costoVivienda = teclado.nextDouble();
                    while (costoVivienda < minMonto) {
                        System.out.println("Valor no permitido. Ingrese un valor mayor o igual a $" + minMonto + ":");
                        costoVivienda = teclado.nextDouble();
                    }
                    break;
                case 5:
                    nombreCredito = "VIVIENDA DE INTERÉS SOCIAL";
                    tasaAnual = 4.87;
                    minMonto = 27058;
                    System.out.println("---------CRÉDITO " + nombreCredito + "---------");
                    System.out.println("¿Cuál es el valor de  la vivienda? (mínimo $" + minMonto + "):");
                    costoVivienda = teclado.nextDouble();
                    while (costoVivienda < minMonto) {
                        System.out.println("Valor no permitido. Ingrese un valor mayor o igual a $" + minMonto + ":");
                        costoVivienda = teclado.nextDouble();
                    }
                    break;
                case 6:
                    nombreCredito = "EDUCACIÓN SUPERIOR";
                    tasaAnual = 9;
                    minMonto = 500;
                    break;
                default:
                    System.out.println("Opción no válida.");
                    teclado.close();
                    return;
            }
    
            double dinero;
            int meses=0;
            System.out.println("---------CRÉDITO " + nombreCredito + "---------");
          
            if (oper == 3 || oper == 4 || oper == 5) {
                System.out.print("¿Cuánto dinero necesitas (mínimo $" + minMonto + ")? ");
                dinero = teclado.nextDouble();
                while (dinero < minMonto || dinero > costoVivienda) {
                    System.out.println("Valor no permitido. Ingrese un valor entre $" + minMonto + " y $" + costoVivienda + ":");
                    dinero = teclado.nextDouble();
                }
            } else {
                System.out.print("¿Cuánto dinero necesitas (mínimo $" + minMonto + ")? ");
                dinero = teclado.nextDouble();
                while (dinero < minMonto) {
                    System.out.println("Valor no permitido. Ingrese un valor mayor o igual a $" + minMonto + ":");
                    dinero = teclado.nextDouble();
                }
            }
            if (oper==1) {
                System.out.print("¿En cuántos meses deseas pagarlo (entre 6 y 60 meses)? ");
             meses = teclado.nextInt();
            while (meses < 6 || meses > 60) {
                System.out.println("Número de meses no válido. Ingrese entre 6 y 60:");
                meses = teclado.nextInt();
            }   
            }
            else{
                if (oper==2) {
                    System.out.print("¿En cuántos meses deseas pagarlo (entre 3 y 66 meses)? ");
                      meses = teclado.nextInt();
                    while (meses < 3 || meses > 66) {
                      System.out.println("Número de meses no válido. Ingrese entre 3 y 66:");
                       meses = teclado.nextInt();
                    }
                 }
                 else{
                    if (oper==3) {
                        System.out.print("¿En cuántos meses deseas pagarlo (entre 36 y 240 meses)? ");
                          meses = teclado.nextInt();
                        while (meses < 36 || meses > 240) {
                          System.out.println("Número de meses no válido. Ingrese entre 36 y 240:");
                           meses = teclado.nextInt();
                        }
                     }
                    else{
                    if (oper==4 || oper==5) {
                        System.out.print("¿En cuántos meses deseas pagarlo (entre 240 y 300 meses)? ");
                         meses = teclado.nextInt();
                        while (meses < 240 || meses > 300) {
                          System.out.println("Número de meses no válido. Ingrese entre 240 y 300:");
                           meses = teclado.nextInt();
                        }
                     }
                    else{
                    if (oper==6) {
                        System.out.print("¿En cuántos meses deseas pagarlo (entre 6 y 126 meses)? ");
                          meses = teclado.nextInt();
                        while (meses < 6 || meses > 126) {
                          System.out.println("Número de meses no válido. Ingrese entre 6 y 126:");
                           meses = teclado.nextInt();
                        }
                     }
                }
                
                }
                
                }
            }
            
            
            double tasaMensual = tasaAnual / 12 / 100;
            double amortizacion = dinero / meses;
            double saldo = dinero;
            double totalInteres = 0;
            double totalSeguro = 0;
    
            System.out.println("====================================================");
            System.out.println("\n             TABLA DE AMORTIZACIÓN                ");
            System.out.println("====================================================");
            System.out.println("Producto: " + nombreCredito);
            System.out.println("Monto: $" + df.format(dinero));
            System.out.println("Plazo (meses): " + meses);
            System.out.println("Tasa de interés nominal: " + tasaAnual + "%\n");
    
            System.out.printf("%-8s %-15s %-12s %-12s %-15s %-12s %-12s\n",
                    "Cuota", "Fecha pago", "Capital", "Interés", "Seguro des.", "Valor cuota", "Saldo");
    
            LocalDate fecha = LocalDate.of(2025, 6, 1);
    
            for (int i = 1; i <= meses; i++) {
                double interes = saldo * tasaMensual;
                double seguro = amortizacion * porcentajeSeguro;
                double cuotaTotal = amortizacion + interes + seguro;
    
                totalInteres += interes;
                totalSeguro += seguro;
                saldo -= amortizacion;
                saldo = Math.max(0, saldo);
    
                System.out.printf("%-8d %-15s $%-11s $%-11s $%-14s $%-11s $%-11s\n",
                        i,
                        fecha.format(formatoFecha),
                        df.format(amortizacion),
                        df.format(interes),
                        df.format(seguro),
                        df.format(cuotaTotal),
                        df.format(saldo));
    
                fecha = fecha.plusMonths(1);
            }
    
            System.out.println("\nTotal intereses pagados: $" + df.format(totalInteres));
            System.out.println("Total seguros desgravamen: $" + df.format(totalSeguro));
            
            System.out.println("====================================================================");
            System.out.println("Ingrese (1) si desea repetir el proceso de lo contario ingrese (0)");
            System.out.println("====================================================================");
                r=teclado.nextInt();
            
            }while(r!=0  );
             System.out.println("-------Gracias por confiar en nuestro servicio-------- ");
    
            
    
            teclado.close();
        }
    }
    
