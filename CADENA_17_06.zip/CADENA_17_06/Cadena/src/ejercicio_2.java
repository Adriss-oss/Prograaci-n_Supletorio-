import java.util.LinkedList;

import javax.security.sasl.AuthorizeCallback;

public class ejercicio_2 {
    public static void Imprimir(LinkedList<Automovil> automovil_) {
        for (Automovil automovil : automovil_) {
            System.out.println(automovil.getMarca() + " - " +
                    automovil.getModelo() + " - " +
                    automovil.getAño() + " - ");
        }
    }

    public static void main(String[] args) {
        LinkedList<Automovil> listaAutomoviles = new LinkedList<>();

        Automovil auto1 = new Automovil("VW", "Gol", 2011);
        Automovil auto2 = new Automovil("Kia", "Cerato", 2015);

        listaAutomoviles.add(auto1);
        listaAutomoviles.add(auto2);

        listaAutomoviles.add(new Automovil("Toyota", "rava 4", 2022));
        listaAutomoviles.add(new Automovil("Nissan", "Sentra", 2010));
        listaAutomoviles.add(new Automovil("Ford", "Focus", 2025));

        // Imprimir los automoviles
        Imprimir(listaAutomoviles);

        // Agregar vehiculo al inicio
        listaAutomoviles.addFirst(new Automovil("BMW", "SERIE13", 2024));
        Imprimir(listaAutomoviles);
        // agregar un vehclo al final
        listaAutomoviles.add(new Automovil("Mercedes", "vens", 2025));
        System.out.println(listaAutomoviles.getLast().toString());

        // BUSQUEDA
        System.out.println("--------Busqueda por marca------");
        String _marca = "TOYOTA";
        for (Automovil auto : listaAutomoviles) {
            if (_marca == auto.getMarca().toUpperCase()) {
                System.out.println("Enconteado: " + auto.getModelo());
            }
        }

        //Crear nueva lista de vehiculos exonerados 2023-2025
        System.out.println("-----Busqueda de vehiculos exonerados 2023-2025-----");
        for(Automovil auto : listaAutomoviles){
            if(auto.getAño()>=2023)
            listaAutomovilesexonerados.add(año);
        }


    }

}
