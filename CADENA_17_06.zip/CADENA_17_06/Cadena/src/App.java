public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        //convertir una cadena a un array 
        String cadena="Hola Fundamentos De Programacion";
        String delimitador =",";

        //dividir la cadena usando delimitador 
        String[] vector = cadena.split(delimitador);

        for (String elemento : vector ) {
            System.out.println(elemento);
            
        }
        System.out.println(vector.length);
        }
}
