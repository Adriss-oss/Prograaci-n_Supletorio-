import java.util.LinkedList;

public class listas2 {
    public static void Imprimirlista(LinkedList<String> _lista){
        System.out.println("----------Imprimiendo lista---------");
        for(String elemento : _lista){
            System.out.println(elemento);
        }
    }
    public static void main(String[] args) {
        LinkedList<String> lista1= new LinkedList<>();
        lista1.add("Juan");
        lista1.add("Andres");
        lista1.add("Pablo");
        lista1.add("Camilo");
        lista1.add("Adriana");

        //Imprimir lista 
        Imprimirlista(lista1);
        lista1.add(1,"Ana");
        Imprimirlista(lista1);
        lista1.remove(0);
        Imprimirlista(lista1);
        lista1.remove("Pablo");
        Imprimirlista(lista1);
        System.out.println("Longuitus lista = "+ lista1.size());



        //Limpiar lista 
        lista1.clear();
        if(lista1.isEmpty()){
            System.out.println("Lista sin elementos ");
        }
        Imprimirlista(lista1);





    }


}
