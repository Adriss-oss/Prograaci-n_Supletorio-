import java.util.Scanner;

public class Ejercicio_7 {
public static void main(String[] args) {
    Scanner teclado=new Scanner(System.in);
    int n,i,cont=0;
    System.out.println("Ingrese un Numero: ");
    n = teclado.nextInt();
    i = 1;
    do {
        if (i % 5 == 0) {
            cont += 1;
        }
        i++;
    } while (i <= n);

    System.out.println("La cantidad de multiplos de 5 son : " + cont);
}
}