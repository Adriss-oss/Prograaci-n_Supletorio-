import java.util.Scanner;
public class Ejercicio_1 {
  public static void main(String[] args) {
    //Variables
    int i, ni, nf, c = 0;
    //Entrada
    Scanner teclado = new Scanner(System.in);
    System.out.print("Ingresar el número inical:" );
    ni = teclado.nextInt();
    System.out.print("Ingresar el número final:" );
    nf = teclado.nextInt();
    //Proceso
    i = ni + 1;
    while(i < nf){
      c +=1;
      i++;
    }

    //Salida
    System.out.println("La cantidad de números que contiene es : " + c);
  }
}
