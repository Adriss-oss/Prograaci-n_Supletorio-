import java.util.Scanner;

public class Ejercicio_6{
public static void main(String[] args) {
 Scanner teclado=new Scanner(System.in);
 int m_c_d,n1,n2;
 System.out.println("Ingrese el primer número: ");
        n1 =teclado.nextInt();
        System.out.println("Ingrese el segundo número: ");
        n2 = teclado.nextInt();
        m_c_d = calcularMCD(n1, n2);
        System.out.println("El MCD de " + n1 + " y " + n2 + " es: " + m_c_d);
    }
    public static int calcularMCD(int n1, int n2) {
        while (n2 != 0) {
            int temp = n2;
            n2 = n1 % n2; 
            n1 = temp;  
        }
        return n1; 
    }
}
