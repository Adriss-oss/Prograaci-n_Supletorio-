import java.util.Scanner;

public class Ejercicio_9 {
    public static void main(String[] args) {
        int i, num1, num2, sum1 = 0, sum2 = 0;
        Scanner teclado = new Scanner(System.in);

        System.out.println("Ingrese el número 1: ");
        num1 = teclado.nextInt();

        System.out.println("Ingrese el número 2: ");
        num2 = teclado.nextInt();

        // Calcular suma de divisores propios de num1
        i = 1;
        do {
            if (num1 % i == 0) {
                sum1 += i;
            }
            i++;
        } while (i <= num1 / 2);

        // Calcular suma de divisores propios de num2
        i = 1;
        do {
            if (num2 % i == 0) {
                sum2 += i;
            }
            i++;
        } while (i <= num2 / 2);

        if (num1 == sum2 && num2 == sum1)
            System.out.println("Los números SON amigos");
        else
            System.out.println("Los números NO son amigos");
    }
}
