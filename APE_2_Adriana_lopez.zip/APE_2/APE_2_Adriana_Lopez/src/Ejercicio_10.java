import java.util.Scanner;

public class Ejercicio_10 {
    public static void main(String[] args) {
  int num, base, dig;
  boolean flag;
  Scanner teclado = new Scanner(System.in);
  System.out.print("Ingrese el numero: ");
  num = teclado.nextInt();
  System.out.print("Ingrese su base: ");
  base = teclado.nextInt();
  flag = true;
  do {
      dig = num % 10;
      if (dig >= base) {
          flag = false;
      }
      num /= 10;
  } while (num > 0);
  if (flag){
      System.out.println("La Base del numero es correcta");
  }
      else
      {
      System.out.println("La Base del numero es incorrecta");
  }     
}
}
