import java.util.Scanner;
public class Ejercicio_3 {
  public static void main(String[] args) {
    // Variables
    int d, n, i = 0;
    boolean negativo = false;

    // Entrada
    Scanner teclado = new Scanner(System.in);
    System.out.print("Ingresar un número: ");
    n = teclado.nextInt();

    // Verificar si el número es negativo
    if (n < 0) {
      negativo = true;
      n = -n; // Convertimos a positivo para facilitar el proceso
    }

    // Proceso: invertir el número
    while(n > 0) {
      d = n % 10;
      n = n / 10;
      i = i * 10 + d;
    }
    // Aplicar signo negativo si era necesario
    if (negativo) {
      i = -i;
    }
    // Salida
    System.out.println("El número inverso es: " + i);
  }
}
