import java.util.Scanner;

public class Ejercicio_5 {
public static void main(String[] args) {
    Scanner teclado=new Scanner(System.in);
    int n1,dig,numtp;
    System.out.println("Ingrese un número: ");
    n1= teclado.nextInt();

    System.out.println("Ingrese el dígito a buscar: ");
    dig = teclado.nextInt();

    boolean dig_encontrado= false;
    numtp = n1; 

    while (numtp > 0) {
        int ultimodigito = numtp % 10;

        if (ultimodigito == dig) {
            dig_encontrado = true;
            break; 
        }
        numtp = numtp / 10;
    }
    if (dig_encontrado) {
        System.out.println("El dígito SÍ existe en el número.");
    } else {
        System.out.println("El dígito NO existe en el número.");
    }

}
}