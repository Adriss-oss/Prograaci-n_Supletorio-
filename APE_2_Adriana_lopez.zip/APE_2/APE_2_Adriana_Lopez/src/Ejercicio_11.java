import java.util.Scanner;

public class Ejercicio_11 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int inicio, fin, primos = 0,i;
        System.out.println("Escriba el rango a iniciar: ");
        inicio = teclado.nextInt();
        System.out.println("Escriba el rango a terminar: ");
        fin = teclado.nextInt();
        i = inicio;
        do {
            boolean esPrimo = true;
            if (i < 2) {
                esPrimo = false;
            } else {
                for (int j = 2; j <= Math.sqrt(i); j++) {
                    if (i % j == 0) {
                        esPrimo = false;
                    }
                }
            }
            if (esPrimo) {
                primos++;
            }
            i++;
        } while (i <= fin);
        System.out.println("Cantidad de números primos entre " + inicio + " y " + fin + ": " + primos);
}
}