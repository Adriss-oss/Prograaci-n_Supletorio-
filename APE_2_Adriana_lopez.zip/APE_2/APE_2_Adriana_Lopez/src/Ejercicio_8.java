import java.util.Scanner;

public class Ejercicio_8 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int dig, mayor = 0, n;

        System.out.print("Ingrese un Número: ");
        n = teclado.nextInt();

        // Asegurarse de trabajar con valor positivo
        n = Math.abs(n);

        do {
            dig = n % 10;
            if (dig > mayor) {
                mayor = dig;
            }
            n /= 10;
        } while (n > 0);

        System.out.println("El dígito mayor es: " + mayor);
    }
}
