import java.util.Scanner;
public class Ejercicio_4 {
  public static void main(String[] args) {
    //Variables
    int n, b, d, i = 0, r = 0;
    //Entrada
    Scanner teclado = new Scanner(System.in);
    System.out.print("El número Base 10:" );
    n = teclado.nextInt();
    System.out.print("Convertir a base:" );
    b = teclado.nextInt();
    //Proceso
    while(n > 0) {
      d = n % b;
      n /= b;
      i = i * 10 + d;
    }
    while(i > 0){
      d = i % 10;
      i /= 10;
      r = r * 10 + d;
    }
    //Salida
    System.out.println("El resultado es:"  + r);
  }
}
