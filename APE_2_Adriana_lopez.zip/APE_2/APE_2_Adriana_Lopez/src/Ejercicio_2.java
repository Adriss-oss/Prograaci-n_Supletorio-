import java.util.Scanner;
public class Ejercicio_2 {
  public static void main(String[] args) {
    //Variables
    int i, d, c = 0, n;
    //Entrada
    Scanner teclado = new Scanner(System.in);
    System.out.print("Ingresar un número : ");
    n = teclado.nextInt();

    //Proceso
    while(n > 0){
      d = n % 10;
      if(d % 2 == 0) {
        c += 1;
      }
      n /= 10;
    }
    //Salida
    System.out.println("Cantidad de  Digitos pares es:"  + c);
  }
}
