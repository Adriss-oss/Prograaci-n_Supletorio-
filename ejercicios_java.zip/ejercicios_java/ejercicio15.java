import java.util.Scanner;

public class ejercicio15 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int dia, mes, anio, diasEnMes;

        System.out.print("Ingrese el día: ");
        dia = scanner.nextInt();

        System.out.print("Ingrese el mes (número del mes que desea ingresar): ");
        mes = scanner.nextInt();

        System.out.print("Ingrese el año: ");
        anio = scanner.nextInt();

        // Determinar cuántos días tiene el mes
        switch (mes) {
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                diasEnMes = 31;
                break;
            case 4: case 6: case 9: case 11:
                diasEnMes = 30;
                break;
            case 2:
                // Verificar si el año es bisiesto para febrero
                if ((anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0)) {
                    diasEnMes = 29;  // Año bisiesto
                } else {
                    diasEnMes = 28;  // Año no bisiesto
                }
                break;
            default:
                diasEnMes = -1;  // Mes no válido
        }

        // Validación de la fecha
        if (diasEnMes == -1) {
            System.out.println("Fecha inválida: el mes no existe.");
        } else {
            if (dia >= 1 && dia <= diasEnMes && anio > 0) {
                System.out.println("La fecha es válida: " + dia + "/" + mes + "/" + anio);
            } else {
                System.out.println("La fecha NO es válida.");
            }
        }

        scanner.close();
    }
}
