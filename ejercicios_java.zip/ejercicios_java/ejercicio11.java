import java.util.Scanner;

public class ejercicio11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String num;
        int resultado;

        System.out.print("Ingresar un número entre 0 y 9.999: ");
        num = scanner.nextLine();

        System.out.println("--------------------------------------");

        // Eliminamos posibles puntos decimales y contamos los caracteres
        resultado = num.replace(".", "").length();

        System.out.println("Tiene " + resultado + " cifras.");

        scanner.close();
    }
}
