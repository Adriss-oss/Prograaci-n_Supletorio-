import java.util.Scanner;

public class ejercicio16 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int dia1, mes1, anio1, dia2, mes2, anio2;
        int totalDias1, totalDias2, diferencia;

        System.out.println("------------------------------------------------");
        System.out.println("Ingrese la primera fecha:");
        System.out.print("Día: ");
        dia1 = scanner.nextInt();
        System.out.print("Mes: ");
        mes1 = scanner.nextInt();
        System.out.print("Año: ");
        anio1 = scanner.nextInt();
        System.out.println("------------------------------------");

        System.out.println("Ingrese la segunda fecha:");
        System.out.print("Día: ");
        dia2 = scanner.nextInt();
        System.out.print("Mes: ");
        mes2 = scanner.nextInt();
        System.out.print("Año: ");
        anio2 = scanner.nextInt();

        // Calcular el total de días para cada fecha (simplificación de 360 días por año y 30 días por mes)
        totalDias1 = anio1 * 360 + mes1 * 30 + dia1;
        totalDias2 = anio2 * 360 + mes2 * 30 + dia2;

        // Calcular la diferencia en días entre las dos fechas
        diferencia = Math.abs(totalDias1 - totalDias2);

        // Mostrar la diferencia
        System.out.println("La diferencia en días entre las dos fechas es: " + diferencia);

        scanner.close();
    }
}
