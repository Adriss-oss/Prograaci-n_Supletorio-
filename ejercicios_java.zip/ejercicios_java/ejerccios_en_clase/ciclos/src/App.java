import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        //sumatoria de nuemros
        //excepto si son miultiplos de 3 
        int rang_inicial=0,rang_final=0,sumatoria=0;
        Scanner teclado = new Scanner(System.in);
        //Variebles de entrada
        System.out.println("Ingrese el rango inferior: ");
        rang_inicial=teclado.nextInt();
        System.out.println("Ingresar el rango Superior: ");
        rang_final=teclado.nextInt();
        
        for (int i = rang_inicial; i <= rang_final; i++) {
           // if (i%3!=0) {
           //     System.out.println(i);
            //    sumatoria+=i;  
            //}
            if (i==5) {
                continue;
            }
            System.out.println("i= "+i);
            //sumatoria+=i;  
            }
           // System.out.println("La sumatoria es. "+sumatoria);
        }
    }

