import java.util.Scanner;

public class ejercicio3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double radio, p, resultado;

        System.out.println("----------------------------");
        System.out.println("CALCULAR LA LONGITUD");
        System.out.println("----------------------------");

        System.out.print("Ingresar el valor del radio en centímetros: ");
        radio = scanner.nextDouble();

        p = 3.1416;
        resultado = 2 * p * radio;

        System.out.println("La longitud en centímetros es: " + resultado);

        scanner.close();
    }
}
