import java.util.Scanner;

public class ejercicio12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double num, orig, inver, dig;
        
        System.out.print("Escriba cualquier número entre 0 y 9.999: ");
        num = scanner.nextDouble();

        orig = num;
        inver = 0;

        while (num > 0) {
            dig = num % 10;  // Obtener el último dígito
            inver = inver * 10 + dig;  // Invertir el número
            num = Math.floor(num / 10);  // Eliminar el último dígito
        }

        if (orig == inver) {
            System.out.println("El número " + orig + " es un palíndromo.");
        } else {
            System.out.println("El número " + orig + " no es un palíndromo.");
        }

        scanner.close();
    }
}

