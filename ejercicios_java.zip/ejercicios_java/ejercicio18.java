import java.util.Scanner;

public class ejercicio18 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double num;

        // Repetir hasta que se ingrese el número 0
        do {
            System.out.print("Introduce un número (0 para salir): ");
            num = scanner.nextDouble();

            if (num > 0) {
                System.out.println("El número es positivo.");
            } else if (num < 0) {
                System.out.println("El número es negativo.");
            }

        } while (num != 0); // El ciclo se repite hasta que el número sea 0

        System.out.println("Fin del programa. Se introdujo un 0.");

        scanner.close();
    }
}
