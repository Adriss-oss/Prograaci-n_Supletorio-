import java.util.Scanner;

public class ejercicio7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double num1, num2;

        System.out.print("Ingresar el primer número: ");
        num1 = scanner.nextDouble();

        System.out.print("Ingresar el segundo número: ");
        num2 = scanner.nextDouble();

        if (num1 > num2) {
            System.out.println(num1 + " es el número mayor.");
        } else if (num2 > num1) {
            System.out.println(num2 + " es el número mayor.");
        } else {
            System.out.println("Ambos números son iguales.");
        }

        scanner.close();
    }
}
