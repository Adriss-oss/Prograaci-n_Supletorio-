import java.util.Scanner;

public class ejercicio13 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double nota;

        System.out.print("Ingresar una Nota: ");
        nota = scanner.nextDouble();

        System.out.println("----------------------------------------");

        if (nota >= 7) {
            System.out.println("SATISFACTORIO");
        } else if (nota <= 5) {
            System.out.println("INSUFICIENTE");
        } else {
            System.out.println("SUFICIENTE");
        }

        scanner.close();
    }
}
