import java.util.Scanner;

public class ejercicio6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double num1, num2;
        double ope;

        System.out.print("Ingresar el primer número: ");
        num1 = scanner.nextDouble();

        System.out.print("Ingresar el segundo número: ");
        num2 = scanner.nextDouble();

        if (num2 == 0) {
            System.out.println("No se puede dividir entre cero.");
        } else {
            ope = num1 % num2;

            if (ope == 0) {
                System.out.println("Los números ingresados son múltiplos.");
            } else {
                System.out.println("Los números ingresados no son múltiplos.");
            }
        }

        scanner.close();
    }
}

