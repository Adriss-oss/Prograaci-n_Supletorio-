import java.util.Scanner;
import java.util.Random;

public class ejercicio20 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        
        int num1 = random.nextInt(100) + 1;  // Genera un número aleatorio entre 1 y 100
        int num;
        int b = 10;  // Número de intentos
        
        System.out.println("Número aleatorio generado: " + num1); // Para ver el número aleatorio (opcional)
        
        // Iniciar los intentos
        for (int i = b; i >= 1; i--) {
            System.out.print("TIENES " + i + " INTENTOS, INGRESA UN NÚMERO DEL 1 AL 100: ");
            num = scanner.nextInt();

            if (num > num1) {
                System.out.println("EL NÚMERO ES MENOR");
            } else if (num < num1) {
                System.out.println("EL NÚMERO ES MAYOR");
            } else {
                System.out.println("¡FELICIDADES! ADIVINASTE EL NÚMERO");
                b = 1; // Si adivina el número, termina el ciclo
                break; // Sale del ciclo de intentos
            }
            
            if (b == 1 && num != num1) {
                System.out.println("-------------------------------------------");
                System.out.println("LO SIENTO, NO ADIVINASTE :(");
            }
        }

        scanner.close();
    }
}

