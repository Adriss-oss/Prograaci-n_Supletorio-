import java.util.Scanner;

public class ejercicio8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double num1, num2;

        System.out.print("Ingresar el primer número: ");
        num1 = scanner.nextDouble();

        System.out.print("Ingresar el segundo número: ");
        num2 = scanner.nextDouble();

        System.out.println("----------------------------------------");

        if (num1 == num2) {
            System.out.println(num1 + " - Los números ingresados son iguales.");
        } else {
            if (num1 > num2) {
                System.out.println(num1 + " es el número mayor.");
            } else {
                System.out.println(num2 + " es el número mayor.");
            }
        }

        scanner.close();
    }
}
