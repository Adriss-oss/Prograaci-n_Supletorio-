import java.util.Scanner;

public class ejercicio4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double num1, num2;

        System.out.print("Ingresar el primer número: ");
        num1 = scanner.nextDouble();

        System.out.print("Ingresar el segundo número: ");
        num2 = scanner.nextDouble();

        if (num1 == num2) {
            System.out.println("Los números ingresados son iguales.");
        } else {
            System.out.println("Los números ingresados no son iguales.");
        }

        scanner.close();
    }
}

