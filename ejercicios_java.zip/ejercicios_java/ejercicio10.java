import java.util.Scanner;

public class ejercicio10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double num1, num2, num3;

        System.out.print("Ingresar el primer número: ");
        num1 = scanner.nextDouble();

        System.out.print("Ingresar el segundo número: ");
        num2 = scanner.nextDouble();

        System.out.print("Ingresar el tercer número: ");
        num3 = scanner.nextDouble();

        System.out.println("----------------------------------------");

        if (num1 == num2 && num1 == num3) {
            System.out.println(num1 + " - " + num2 + " - " + num3);
        } else {
            // Ordenar de mayor a menor
            double mayor, medio, menor;

            if (num1 >= num2 && num1 >= num3) {
                mayor = num1;
                if (num2 >= num3) {
                    medio = num2;
                    menor = num3;
                } else {
                    medio = num3;
                    menor = num2;
                }
            } else if (num2 >= num1 && num2 >= num3) {
                mayor = num2;
                if (num1 >= num3) {
                    medio = num1;
                    menor = num3;
                } else {
                    medio = num3;
                    menor = num1;
                }
            } else {
                mayor = num3;
                if (num1 >= num2) {
                    medio = num1;
                    menor = num2;
                } else {
                    medio = num2;
                    menor = num1;
                }
            }

            System.out.println(mayor + " ; " + medio + " ; " + menor);
        }

        scanner.close();
    }
}
