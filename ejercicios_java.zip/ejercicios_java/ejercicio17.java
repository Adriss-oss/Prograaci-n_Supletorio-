import java.util.Scanner;

public class ejercicio17 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double num, cuadrado;

        // Repetir hasta que se ingrese un número negativo
        do {
            System.out.print("Introduce un número: ");
            num = scanner.nextDouble();

            if (num >= 0) {
                System.out.println(num); // Imprimir el número ingresado
                cuadrado = num * num; // Calcular el cuadrado
                System.out.println("El cuadrado es: " + cuadrado);
            }

        } while (num >= 0); // La condición de repetición es que el número sea mayor o igual a 0

        System.out.println("Fin del programa. Se introdujo un número negativo.");

        scanner.close();
    }
}
