import java.util.Scanner;

public class ejercicio2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double radio, p, resultado;

        System.out.println("----------------------");
        System.out.println("CALCULAR EL ÁREA");
        System.out.println("----------------------");

        System.out.print("Ingresar el valor del radio en centímetros: ");
        radio = scanner.nextDouble();

        p = 3.1416;
        resultado = p * Math.pow(radio, 2);

        System.out.println("El Área en centímetros cuadrados es: " + resultado);

        scanner.close();
    }
}
