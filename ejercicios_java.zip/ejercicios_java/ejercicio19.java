import java.util.Scanner;

public class ejercicio19 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int num;

        // Repetir hasta que se ingrese el número 0
        do {
            System.out.print("Introduce un número (0 para salir): ");
            num = scanner.nextInt();

            if (num != 0) {
                if (num % 2 == 0) {
                    System.out.println("El número es par.");
                } else {
                    System.out.println("El número es impar.");
                }
            }

        } while (num != 0); // El ciclo se repite hasta que el número sea 0

        System.out.println("Fin del programa. Se introdujo un 0.");

        scanner.close();
    }
}

