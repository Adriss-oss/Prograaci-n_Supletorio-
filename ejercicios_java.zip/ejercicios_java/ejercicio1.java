import java.util.Scanner;

public class ejercicio1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        double val_1, val_2, val_3, op, resultado_1, resultado_2;

        System.out.println("----------------------------------");
        System.out.println("COEFICIENTES DE UNA ECUACIÓN");
        System.out.println("=> ax^2 + bx + c");
        System.out.println("----------------------------------");

        System.out.print("Ingresar el valor de a: ");
        val_1 = scanner.nextDouble();

        System.out.print("Ingresar el valor de b: ");
        val_2 = scanner.nextDouble();

        System.out.print("Ingresar el valor de c: ");
        val_3 = scanner.nextDouble();

        System.out.println("----------------------------------");

        op = Math.pow(val_2, 2) - (4 * val_1 * val_3);

        if (val_1 == 0) {
            System.out.println("No es una ecuación de segundo grado. 'a' no puede ser igual a 0.");
        } else {
            if (op < 0) {
                System.out.println("La ecuación no tiene soluciones reales.");
            } else {
                resultado_1 = (-val_2 + Math.sqrt(op)) / (2 * val_1);
                resultado_2 = (-val_2 - Math.sqrt(op)) / (2 * val_1);
                System.out.println("La respuesta de la ecuación es: (X1 = " + resultado_1 + "; X2 = " + resultado_2 + ")");
            }
        }

        scanner.close();
    }
}

