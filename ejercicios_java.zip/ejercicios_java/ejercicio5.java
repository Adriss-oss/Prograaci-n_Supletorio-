import java.util.Scanner;

public class ejercicio5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double num1;

        System.out.print("Ingresar un número: ");
        num1 = scanner.nextDouble();

        if (num1 == 0) {
            System.out.println("El número es neutro.");
        } else {
            if (num1 > 0) {
                System.out.println("El número que ingresó es positivo.");
            } else {
                System.out.println("El número que ingresó es negativo.");
            }
        }

        scanner.close();
    }
}

