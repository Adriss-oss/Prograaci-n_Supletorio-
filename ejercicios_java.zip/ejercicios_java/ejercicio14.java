import java.util.Scanner;

public class ejercicio14 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int dia, mes, anio;

        System.out.print("Ingrese el día: ");
        dia = scanner.nextInt();

        System.out.print("Ingrese el mes: ");
        mes = scanner.nextInt();

        System.out.print("Ingrese el año: ");
        anio = scanner.nextInt();

        System.out.println("----------------------------------------");

        if (dia >= 1 && dia <= 30 && mes >= 1 && mes <= 12 && anio > 0) {
            System.out.println("La fecha es válida: " + dia + "/" + mes + "/" + anio);
        } else {
            System.out.println("La fecha NO es válida.");
        }

        scanner.close();
    }
}

