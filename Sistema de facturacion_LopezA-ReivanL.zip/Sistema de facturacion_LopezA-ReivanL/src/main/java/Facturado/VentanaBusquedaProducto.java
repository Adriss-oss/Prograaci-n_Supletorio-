/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Facturado;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;
/**
 *
 * @author nicol
 */

public class VentanaBusquedaProducto extends JDialog {
    private JTable tablaProductos;
    private DefaultTableModel modelo;
    private Producto productoSeleccionado = null;

    public VentanaBusquedaProducto(JFrame parent) {
        super(parent, "Buscar Producto", true);
        setSize(700, 400);
        setLayout(null);
        setLocationRelativeTo(parent);

        modelo = new DefaultTableModel(new Object[]{"ID", "Nombre", "Detalle", "Precio", "Stock"}, 0);
        tablaProductos = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tablaProductos);
        scroll.setBounds(20, 20, 650, 250);
        add(scroll);

        JButton btnSeleccionar = new JButton("Seleccionar");
        btnSeleccionar.setBounds(280, 290, 120, 30);
        add(btnSeleccionar);

        cargarProductos();

        btnSeleccionar.addActionListener(e -> {
            int fila = tablaProductos.getSelectedRow();
            if (fila >= 0) {
                productoSeleccionado = new Producto(
                    modelo.getValueAt(fila, 0).toString(),  
                    modelo.getValueAt(fila, 1).toString(),  
                    modelo.getValueAt(fila, 2).toString(),  
                    Double.parseDouble(modelo.getValueAt(fila, 3).toString()),  
                    Integer.parseInt(modelo.getValueAt(fila, 4).toString())     
                );
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Seleccione un producto de la tabla.");
            }
        });
    }

    private void cargarProductos() {
        List<Producto> productos = Utilidades.cargarProductos("data/productos.csv");
        for (Producto p : productos) {
            modelo.addRow(new Object[]{p.getId(), p.getNombre(), p.getDetalle(), p.getPrecio(), p.getStock()});
        }
    }

    public Producto getProductoSeleccionado() {
        return productoSeleccionado;
    }
}
