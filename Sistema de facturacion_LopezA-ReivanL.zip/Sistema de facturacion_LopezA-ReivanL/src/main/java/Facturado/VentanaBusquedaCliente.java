/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Facturado;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

/**
 *
 * @author nicol
 */

public class VentanaBusquedaCliente extends JDialog {
    private JTable tablaClientes;
    private DefaultTableModel modelo;
    private Cliente clienteSeleccionado = null;

    public VentanaBusquedaCliente(JFrame parent, String filtroInicial) {
        super(parent, "Buscar Cliente", true);
        setSize(700, 400);
        setLayout(null);
        setLocationRelativeTo(parent);

        modelo = new DefaultTableModel(new Object[]{"Cédula", "Nombre", "Apellido", "Dirección", "Teléfono", "Correo"}, 0);
        tablaClientes = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tablaClientes);
        scroll.setBounds(20, 60, 650, 200);
        add(scroll);

        JLabel lblBuscar = new JLabel("Buscar:");
        lblBuscar.setBounds(20, 20, 60, 20);
        add(lblBuscar);

        JTextField txtBuscar = new JTextField(filtroInicial); 
        txtBuscar.setBounds(80, 20, 180, 25);
        add(txtBuscar);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(270, 20, 100, 25);
        add(btnBuscar);

        JButton btnSeleccionar = new JButton("Seleccionar");
        btnSeleccionar.setBounds(280, 280, 120, 30);
        add(btnSeleccionar);

        cargarClientes(filtroInicial);

        btnBuscar.addActionListener(e -> {
            String texto = txtBuscar.getText().trim();
            cargarClientes(texto);
        });

        btnSeleccionar.addActionListener(e -> {
    int fila = tablaClientes.getSelectedRow();
    if (fila >= 0) {
        clienteSeleccionado = new Cliente(
            modelo.getValueAt(fila, 0).toString(),
            modelo.getValueAt(fila, 1).toString(), 
            modelo.getValueAt(fila, 2).toString(),
            modelo.getValueAt(fila, 4).toString(), 
            modelo.getValueAt(fila, 5).toString(), 
            modelo.getValueAt(fila, 3).toString() 
        );
        dispose();
    } else {
        JOptionPane.showMessageDialog(this, "Seleccione un cliente de la tabla.");
    }
});
    }

    private void cargarClientes(String filtro) {
        List<Cliente> clientes = Utilidades.cargarClientes("data/clientes.csv");
        modelo.setRowCount(0); // limpiar tabla

        for (Cliente c : clientes) {
            if (filtro.isEmpty() ||
                c.getCedula().toLowerCase().contains(filtro.toLowerCase()) ||
                c.getNombre().toLowerCase().contains(filtro.toLowerCase()) ||
                c.getApellido().toLowerCase().contains(filtro.toLowerCase()) ||
                c.getDireccion().toLowerCase().contains(filtro.toLowerCase()) ||   
                c.getTelefono().toLowerCase().contains(filtro.toLowerCase()) ||
                c.getCorreo().toLowerCase().contains(filtro.toLowerCase())) {

                modelo.addRow(new Object[]{
                    c.getCedula(),
                    c.getNombre(),
                    c.getApellido(),
                    c.getDireccion(),
                    c.getTelefono(),
                    c.getCorreo()
                });
            }
        }
    }

    public Cliente getClienteSeleccionado() {
        return clienteSeleccionado;
    }
}
