/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Facturado;

/**
 *
 * @author nicol
 */

public class Producto {
    private String id, nombre, detalle;
    private double precio;
    private int stock;

    public Producto(String id, String nombre, String detalle, double precio, int stock) { //Este es el Constructor
        this.id = id;
        this.nombre = nombre;
        this.detalle = detalle;
        this.precio = precio;
        this.stock = stock;
    }

    // Getters
    public String getId() { 
        return id; 
    }
    public String getNombre() { 
        return nombre; 
    }
    public String getDetalle() { 
        return detalle; 
    }
    public double getPrecio() { 
        return precio; 
    }
    public int getStock() { 
        return stock; 
    }

    @Override
    public String toString() {
        return nombre + " - $" + precio; // Imprime el precio
    }
}
