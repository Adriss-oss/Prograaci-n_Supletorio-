/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Facturado;
import java.io.*;
import java.util.*;
import java.nio.file.*;
import java.util.List;

/**
 *
 * @author nicol
 */
public class Utilidades {

    public static List<Cliente> cargarClientes(String ruta) {
    List<Cliente> lista = new ArrayList<>();
    try (BufferedReader br = Files.newBufferedReader(Paths.get(ruta))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            String[] partes = linea.split(",");
            if (partes.length == 6) {
                lista.add(new Cliente(partes[0], partes[1], partes[2], partes[3], partes[4], partes[5]));
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
    return lista;
}


    public static List<Producto> cargarProductos(String ruta) {
        List<Producto> lista = new ArrayList<>();
        try (BufferedReader br = Files.newBufferedReader(Paths.get(ruta))) {
            String linea = br.readLine(); 
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 5) {
                    lista.add(new Producto(partes[0], partes[1], partes[2], Double.parseDouble(partes[3]), Integer.parseInt(partes[4])));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lista;   
     
    }
    public static boolean guardarCliente(Cliente c, String ruta) {
    try {
        List<Cliente> clientes = cargarClientes(ruta);

        boolean existe = clientes.stream()
            .anyMatch(cliente -> cliente.getCedula().equals(c.getCedula()));

        if (existe) {
            return false; 
        }

        try (BufferedWriter bw = Files.newBufferedWriter(
                Paths.get(ruta),
                StandardOpenOption.APPEND,
                StandardOpenOption.CREATE)) {

            String linea = String.join(",",
                    c.getCedula(),
                    c.getNombre(),
                    c.getApellido(),
                    c.getTelefono(), 
                    c.getCorreo(),   
                    c.getDireccion()  
            );

            bw.write(linea);
            bw.newLine();
            return true; 

        } catch (IOException e) {
            System.out.println("Error al guardar cliente: " + e.getMessage());
        }

    } catch (Exception e) {
        System.out.println("Error general al procesar cliente: " + e.getMessage());
    }
    return false;
}
    
    public static void guardarNumeroFactura(int numero) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("data/numeroFactura.txt"))) {
            writer.write(String.valueOf(numero));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static int cargarNumeroFactura() {
        try (BufferedReader reader = new BufferedReader(new FileReader("data/numeroFactura.txt"))) {
            return Integer.parseInt(reader.readLine());
        } catch (IOException | NumberFormatException e) {
            return 1; 
        }
    }
}

