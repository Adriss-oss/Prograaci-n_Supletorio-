/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Facturado;

/**
 *
 * @author nicol
 */

public class Cliente {
    private String cedula, nombre, apellido, telefono, correo, direccion;

    public Cliente(String cedula, String nombre, String apellido, String telefono, String correo, String direccion) { //Este es el Constructor
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.correo = correo;
        this.direccion = direccion;
    }

    // Getters y Setters
    public String getCedula() { 
        return cedula; 
    }
    public String getNombre() { 
        return nombre; 
    }
    public String getApellido() { 
        return apellido; 
    }
    public String getTelefono() { 
        return telefono; 
    }
    public String getCorreo() { 
        return correo; 
    }
    public String getDireccion() { 
        return direccion; 
    }

    @Override
    public String toString() {
        return nombre + " " + apellido + " - " + cedula; // Imprime Los datos nombre, apellido y cedula
    }
}
