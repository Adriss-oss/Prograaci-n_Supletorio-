/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Facturado;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;//Para modificar los modelos de datos de la tabla, nos ayuda a agregar, eliminar o modificar filas y columnas dinamicamente.
import java.io.File;//Se uso para manipular archivos y directorios
import java.text.DecimalFormat;//Dar formato a numeros decimales
import java.text.SimpleDateFormat;//Dar formato a la fecha
import java.util.*;
import java.awt.Desktop; //Se uso para abrir el archivo pdf
import com.itextpdf.kernel.pdf.*;//para crear, leer y manipular nuestro pdf
import com.itextpdf.layout.*;//Para agregar contenido al pdf (factura)
import com.itextpdf.layout.element.*;//Define los eementos que podemos agregar al pdf
import com.itextpdf.layout.properties.TextAlignment;//Alineacion de texto del pdf
import com.itextpdf.layout.properties.UnitValue;//Para definir el tamaño de las tablas y margenes
import com.itextpdf.layout.properties.HorizontalAlignment;//Para la alineaccion de los elemetos del pdf
import java.awt.Font; //para fuentes y elemento graficos
import java.io.FileNotFoundException;//Es para cuando se intenta lee el archivo y no se encuentra en el sistema este va a lanzar una excepcion
import java.util.logging.Level;//Para definir niveles de severidad de los errores
import java.util.logging.Logger;//Para dar los mensajes diagnosticos 
import javax.swing.border.TitledBorder;//Para añadir bordes a los paneles

/**
 *
 * @author nicol
 */
public class VentanaPrincipal extends JFrame {
    private JTextField txtCedula, txtNombre, txtApellido, txtDireccion, txtTelefono, txtCorreo;
    private JTextField txtNumeroFactura, txtFecha;
    private JTextField txtProducto, txtPrecio, txtCantidad;
    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private JTextField txtSubtotal, txtIVA, txtTotal;

    DecimalFormat formato = new DecimalFormat("#.00");

    public VentanaPrincipal() {
        setTitle("SISTEMA DE FACTURIZACION");
        setSize(1000, 750);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JLabel lblTitulo = new JLabel("SISTEMA DE FACTURIZACION");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        lblTitulo.setBounds(320, 10, 400, 30);
        add(lblTitulo);

        
        // Datos cliente
        JPanel panelCliente = new JPanel(null);
        panelCliente.setBounds(20, 50, 900, 90);
        panelCliente.setBorder(new TitledBorder("Datos del Cliente"));
        add(panelCliente); 
        
        
        JLabel lblCI = new JLabel("C.I:");
        lblCI.setBounds(30, 50, 50, 20);
        add(lblCI);
        
        panelCliente.add(new JLabel("C.I:")).setBounds(20, 25, 30, 20);
        txtCedula = new JTextField();
        txtCedula.setBounds(50, 25, 80, 20);
        panelCliente.add(txtCedula);

        
        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(160, 50, 60, 20);
        add(lblNombre);
        
        panelCliente.add(new JLabel("Nombre:")).setBounds(140, 25, 60, 20);
        txtNombre = new JTextField();
        txtNombre.setBounds(200, 25, 120, 20);
        panelCliente.add(txtNombre);

        
        JLabel lblApellido = new JLabel("Apellido:");
        lblApellido.setBounds(380, 50, 60, 20);
        add(lblApellido);

        panelCliente.add(new JLabel("Apellido:")).setBounds(330, 25, 60, 20);
        txtApellido = new JTextField();
        txtApellido.setBounds(390, 25, 120, 20);
        panelCliente.add(txtApellido);

        
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(780, 55, 90, 25);
        panelCliente.add(btnBuscar);
        btnBuscar.addActionListener(e -> {
    String filtro = txtCedula.getText().trim();

    if (filtro.isEmpty()) {
        filtro = txtNombre.getText().trim();
    }
    if (filtro.isEmpty()) {
        filtro = txtApellido.getText().trim();
    }

    VentanaBusquedaCliente ventana = new VentanaBusquedaCliente(this, filtro);
    ventana.setVisible(true);

    Cliente seleccionado = ventana.getClienteSeleccionado();
if (seleccionado != null) {
    txtCedula.setText(seleccionado.getCedula());
    txtNombre.setText(seleccionado.getNombre());
    txtApellido.setText(seleccionado.getApellido());
    txtDireccion.setText(seleccionado.getDireccion());
    txtTelefono.setText(seleccionado.getTelefono());
    txtCorreo.setText(seleccionado.getCorreo());
}

});        

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(680, 55, 90, 25);
        panelCliente.add(btnGuardar);
        btnGuardar.addActionListener(e -> {
    String cedula = txtCedula.getText();
    String nombre = txtNombre.getText();
    String apellido = txtApellido.getText();
    String direccion = txtDireccion.getText();
    String telefono = txtTelefono.getText();
    String correo = txtCorreo.getText().trim();

    
    if (cedula.isEmpty() || nombre.isEmpty() || apellido.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, llena al menos cédula, nombre y apellido.");
    } else {
        // Línea correcta
        Cliente nuevo = new Cliente(cedula, nombre, apellido, telefono, correo, direccion);
        boolean guardado = Utilidades.guardarCliente(nuevo, "data/clientes.csv");

        if (guardado) {
            JOptionPane.showMessageDialog(this, "Cliente registrado con éxito.");
        } else {
            JOptionPane.showMessageDialog(this, "El cliente ya está registrado.", "Duplicado", JOptionPane.WARNING_MESSAGE);
        }
    }
});

        

        JLabel lblDir = new JLabel("Dirección:");
        lblDir.setBounds(30, 80, 70, 20);
        add(lblDir);

        panelCliente.add(new JLabel("Dirección:")).setBounds(520, 25, 70, 20);
        txtDireccion = new JTextField();
        txtDireccion.setBounds(590, 25, 120, 20);
        panelCliente.add(txtDireccion);

        
        JLabel lblTel = new JLabel("Teléfono:");
        lblTel.setBounds(270, 80, 60, 20);
        add(lblTel);

        panelCliente.add(new JLabel("Teléfono:")).setBounds(720, 25, 60, 20);
        txtTelefono = new JTextField();
        txtTelefono.setBounds(780, 25, 100, 20);
        panelCliente.add(txtTelefono);
        
        
        JLabel lblCorreo = new JLabel("Correo:");
        lblCorreo.setBounds(20, 55, 50, 20); 
        panelCliente.add(lblCorreo);
        
        txtCorreo = new JTextField();
        txtCorreo.setBounds(80, 55, 200, 20); 
        panelCliente.add(txtCorreo);

        
        // Datos de la Factura
        JPanel panelFactura = new JPanel(null);
        panelFactura.setBounds(20, 145, 900, 60);
        panelFactura.setBorder(new TitledBorder("Datos de Factura"));
        add(panelFactura);

        panelFactura.add(new JLabel("N° Factura:")).setBounds(30, 25, 80, 20);
        txtNumeroFactura = new JTextField("001");
        txtNumeroFactura.setBounds(100, 25, 80, 20);
        panelFactura.add(txtNumeroFactura);

        JLabel lblFecha = new JLabel("Fecha:");
        lblFecha.setBounds(680, 80, 50, 20);
        add(lblFecha);

         panelFactura.add(new JLabel("Fecha:")).setBounds(200, 25, 50, 20);
        txtFecha = new JTextField(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
        txtFecha.setBounds(250, 25, 100, 20);
        panelFactura.add(txtFecha);

        
        // Producto
        JPanel panelProducto = new JPanel(null);
        panelProducto.setBounds(20, 215, 900, 60);
        panelProducto.setBorder(new TitledBorder("Agregar Producto"));
        add(panelProducto);
        
        
        JLabel lblProd = new JLabel("Producto:");
        lblProd.setBounds(30, 120, 70, 20);
        add(lblProd);

        panelProducto.add(new JLabel("Producto:")).setBounds(30, 25, 70, 20);
        txtProducto = new JTextField();
        txtProducto.setBounds(100, 25, 180, 20);
        panelProducto.add(txtProducto);


        JLabel lblPrecio = new JLabel("Precio:");
        lblPrecio.setBounds(270, 120, 50, 20);
        add(lblPrecio);

        panelProducto.add(new JLabel("Precio:")).setBounds(300, 25, 60, 20);
        txtPrecio = new JTextField();
        txtPrecio.setBounds(350, 25, 70, 20);
        panelProducto.add(txtPrecio);

        
        JLabel lblCant = new JLabel("Cantidad:");
        lblCant.setBounds(400, 120, 60, 20);
        add(lblCant);

        panelProducto.add(new JLabel("Cantidad:")).setBounds(440, 25, 60, 20);
        txtCantidad = new JTextField();
        txtCantidad.setBounds(500, 25, 70, 20);
        panelProducto.add(txtCantidad);

        
        JButton btnAgregar = new JButton("+ Agregar");
        btnAgregar.setBounds(590, 25, 100, 25);
        panelProducto.add(btnAgregar);

        btnAgregar.addActionListener(e -> {
            try {
                String prod = txtProducto.getText();
                int cant = Integer.parseInt(txtCantidad.getText());
                double precio = Double.parseDouble(txtPrecio.getText());
                double subtotal = cant * precio;

                // Agregar valores numéricos sin formato
                modeloTabla.addRow(new Object[]{
                    prod,
                    cant,
                    precio,
                    subtotal
                });

                actualizarTotales();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Verifica los datos ingresados.");
            }
        });

        
        JButton btnProductos = new JButton("Productos");
        btnProductos.setBounds(700, 25, 100, 25);
        panelProducto.add(btnProductos);
        
        btnProductos.addActionListener(e -> {
       VentanaBusquedaProducto ventana = new VentanaBusquedaProducto(this);
       ventana.setVisible(true);
       Producto seleccionado = ventana.getProductoSeleccionado();
        if (seleccionado != null) {
            txtProducto.setText(seleccionado.getNombre());
            txtPrecio.setText(String.valueOf(seleccionado.getPrecio()));
            txtCantidad.setText("1");  // o déjalo vacío si quieres que el usuario lo elija
        }
    });

        
        JButton btnImprimir = new JButton("Imprimir");
        btnImprimir.setBounds(810, 25, 80, 25);
        panelProducto.add(btnImprimir);

        btnImprimir.addActionListener(e -> {
            try {
                generarFacturaPDF(
                        txtNombre.getText(),
                        txtApellido.getText(),
                        txtDireccion.getText(),
                        txtTelefono.getText(),
                        txtNumeroFactura.getText(),
                        txtFecha.getText(),
                        tabla,
                        txtSubtotal.getText(),
                        txtIVA.getText(),
                        txtTotal.getText()
                );
            } catch (FileNotFoundException ex) {
                Logger.getLogger(VentanaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }
    });


        // Tabla
        modeloTabla = new DefaultTableModel(new Object[]{"Producto", "Cantidad", "Precio Unitario", "Subtotal"}, 0);
        tabla = new JTable(modeloTabla);
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBounds(20, 290, 900, 200);
        add(scroll);

        
        // Totales
        JPanel panelTotales = new JPanel(null);
        panelTotales.setBounds(600, 500, 320, 100);
        panelTotales.setBorder(new TitledBorder("Resumen"));
        add(panelTotales);
        
        JLabel lblSub = new JLabel("Subtotal Sin IVA");
        lblSub.setBounds(650, 370, 100, 20);
        add(lblSub);

         panelTotales.add(new JLabel("Subtotal sin IVA:")).setBounds(20, 20, 120, 20);
        txtSubtotal = new JTextField("0.00");
        txtSubtotal.setBounds(150, 20, 100, 20);
        panelTotales.add(txtSubtotal);

        
        JLabel lblIva = new JLabel("I.V.A");
        lblIva.setBounds(650, 400, 100, 20);
        add(lblIva);

        panelTotales.add(new JLabel("IVA (15%):")).setBounds(20, 45, 120, 20);
        txtIVA = new JTextField("0.00");
        txtIVA.setBounds(150, 45, 100, 20);
        panelTotales.add(txtIVA);

        
        JLabel lblTotal = new JLabel("Total a Pagar");
        lblTotal.setBounds(650, 430, 100, 20);
        add(lblTotal);

        panelTotales.add(new JLabel("Total a Pagar:")).setBounds(20, 70, 120, 20);
        txtTotal = new JTextField("0.00");
        txtTotal.setBounds(150, 70, 100, 20);
        panelTotales.add(txtTotal);
        
        //Boton nueva factura
        JButton btnNuevaFactura = new JButton("Nueva Factura");
        btnNuevaFactura.setBounds(750, 160, 120, 25);
        add(btnNuevaFactura);
        
        btnNuevaFactura.addActionListener(e -> {
    // Limpiar datos del cliente
        txtCedula.setText("");
        txtNombre.setText("");
        txtApellido.setText("");
        txtDireccion.setText("");
        txtTelefono.setText("");
        txtCorreo.setText("");

    // Limpiar producto
        txtProducto.setText("");
        txtPrecio.setText("");
        txtCantidad.setText("");

    // Limpiar tabla
        modeloTabla.setRowCount(0);

    // Limpiar totales
        txtSubtotal.setText("0.00");
        txtIVA.setText("0.00");
        txtTotal.setText("0.00");

    // Actualizar fecha y número de factura
        txtFecha.setText(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
    
    // (Opcional) Aumentar el número de factura automáticamente
        try {
            int num = Integer.parseInt(txtNumeroFactura.getText());
            txtNumeroFactura.setText(String.format("%03d", num + 1));
        } catch (NumberFormatException ex) {
            txtNumeroFactura.setText("001");
        }

        JOptionPane.showMessageDialog(this, "Lista para una nueva factura.");
    });

    }

    // Método corregido actualizar totales
    private void actualizarTotales() {
        double sub = 0.0;
        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            Object valor = modeloTabla.getValueAt(i, 3);
            if (valor != null) {
                try {
                    sub += Double.parseDouble(valor.toString());
                } catch (NumberFormatException ex) {
                    System.err.println("Error al convertir subtotal: " + valor);
                }
            }
        }
        double iva = sub * 0.15;
        double total = sub + iva;

        txtSubtotal.setText(formato.format(sub));
        txtIVA.setText(formato.format(iva));
        txtTotal.setText(formato.format(total));
    }

    
   private void generarFacturaPDF(String cliente, String apellido, String direccion, String telefono, String numeroFactura, String fechaFactura, JTable tabla, String subtotal, String iva, String total) throws FileNotFoundException {
    File carpeta = new File("Facturas");
    if (!carpeta.exists()) {
        carpeta.mkdirs();
    }

    String nombreLimpio = (cliente + "_" + apellido).trim().replaceAll("\\s+", "_");
    String fechaLimpia = fechaFactura.trim();
    String nombreArchivo = "Facturas/Factura_" 
        + String.format("%03d", Integer.valueOf(numeroFactura)) 
        + "_" + nombreLimpio 
        + "_" + fechaLimpia + ".pdf";

    try {
        PdfWriter writer = new PdfWriter(nombreArchivo);
        PdfDocument pdf = new PdfDocument(writer);
        Document doc = new Document(pdf);

        // Encabezado
        Paragraph titulo = new Paragraph("SUPERMERCADO LOPEZ & REIVAN")
            .setFontSize(18)
            .setBold()
            .setTextAlignment(TextAlignment.CENTER);
        doc.add(titulo);

        Paragraph sub = new Paragraph("Factura N° " + numeroFactura + "       Fecha: " + fechaFactura)
            .setTextAlignment(TextAlignment.RIGHT)
            .setFontSize(10);
        doc.add(sub);

        // Datos del cliente
        doc.add(new Paragraph("\nDatos del Cliente")
            .setBold()
            .setFontSize(12));

        Paragraph datosCliente = new Paragraph()
            .add("Nombre: " + cliente + " " + apellido + "\n")
            .add("Dirección: " + direccion + "\n")
            .add("Teléfono: " + telefono)
            .setFontSize(10)
            .setPaddingBottom(10);
        doc.add(datosCliente);

        
        // Tabla de productos
        float[] columnas = {4, 2, 2, 2};
        Table table = new Table(UnitValue.createPercentArray(columnas));
        table.setWidth(UnitValue.createPercentValue(100));

        table.addHeaderCell("Producto");
        table.addHeaderCell("Cantidad");
        table.addHeaderCell("Precio Unitario");
        table.addHeaderCell("Subtotal");

        for (int i = 0; i < tabla.getRowCount(); i++) {
            table.addCell(tabla.getValueAt(i, 0).toString());
            table.addCell(tabla.getValueAt(i, 1).toString());
            table.addCell(tabla.getValueAt(i, 2).toString());
            table.addCell(tabla.getValueAt(i, 3).toString());
        }
        doc.add(table);

        
        // Totales
        doc.add(new Paragraph("\n"));
        Table totales = new Table(2);
        totales.setWidth(UnitValue.createPercentValue(40));
        totales.setHorizontalAlignment(HorizontalAlignment.RIGHT);

        totales.addCell(new Cell().add(new Paragraph("Subtotal sin IVA").setBold()));
        totales.addCell(new Cell().add(new Paragraph("$" + subtotal)));

        totales.addCell(new Cell().add(new Paragraph("IVA (15%)").setBold()));
        totales.addCell(new Cell().add(new Paragraph("$" + iva)));

        totales.addCell(new Cell().add(new Paragraph("Total a Pagar").setBold()));
        totales.addCell(new Cell().add(new Paragraph("$" + total).setBold()));

        doc.add(totales);
        doc.close();

        
        // Abrir automáticamente
        try {
            File archivo = new File(nombreArchivo);
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(archivo);
            } else {
                JOptionPane.showMessageDialog(this, "Tu sistema no permite abrir archivos automáticamente.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Factura guardada, pero no se pudo abrir automáticamente:\n" + ex.getMessage());
        }

        
        // Actualizar número de factura
        Utilidades.guardarNumeroFactura(Integer.parseInt(numeroFactura) + 1);
        JOptionPane.showMessageDialog(this, "Factura generada correctamente en:\n" + nombreArchivo);

    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Error al generar la factura PDF:\n" + ex.getMessage());
    }
}
}
