package Ejercicio2;
import java.util.Scanner;

public class Sumar_numeros {

    private Scanner teclado;
    private int num1, num2, num3, num4, num5;

    public void ingresarDatos() {
        teclado = new Scanner(System.in);
        System.out.println("Ingrese 5 números:");
        System.out.print("Ingrese el primer número: ");
        num1 = teclado.nextInt();
        System.out.print("Ingrese el segundo número: ");
        num2 = teclado.nextInt();
        System.out.print("Ingrese el tercer número: ");
        num3 = teclado.nextInt();
        System.out.print("Ingrese el cuarto número: ");
        num4 = teclado.nextInt();
        System.out.print("Ingrese el quinto número: ");
        num5 = teclado.nextInt();
    }

    public int mostrarSumaDeCincoNumeros() {
        int suma = num1 + num2 + num3 + num4 + num5;
        System.out.println("La suma de los 5 números es: " + suma);
        return suma;
    }

    public static void main(String[] args) {
        Sumar_numeros suma_num = new Sumar_numeros();
        suma_num.ingresarDatos();
        suma_num.mostrarSumaDeCincoNumeros();
    }
}
