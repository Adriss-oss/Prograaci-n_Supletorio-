package Ejercicio4;

import java.util.Scanner;

public class Frase {
    
    public void Contarlaspalabras(String frase) {
        String[] palabras = frase.trim().split("\\s+");
        System.out.println("Cantidad de palabras: " + palabras.length);
    }
    
    public void Contarlasletras(String frase) {
        int letras = 0;
        for (char c : frase.toCharArray()) {
            if (Character.isLetter(c)) {
                letras++;
            }
        }
        System.out.println("Cantidad de letras: " + letras);
    }

    public void Contarlasvocales(String frase) {
        int vocales = 0;
        frase = frase.toLowerCase();
        for (char c : frase.toCharArray()) {
            if ("aeiou".indexOf(c) != -1) {
                vocales++;
            }
        }
        System.out.println("Cantidad de vocales: " + vocales);
    }
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        Frase analizador = new Frase();
        String repetir;

        do {
            System.out.println("ingrese una frase");
            String frase = teclado.nextLine();
            analizador.Contarlaspalabras(frase);
            analizador.Contarlasletras(frase);
            analizador.Contarlasvocales(frase);
            System.out.println("desea realizar de nuevo si o no");
            repetir = teclado.nextLine().toLowerCase();
            System.out.println();
        } while (repetir.equals("si"));
       System.out.println("------------------EL PROGRAMA FINALIZO-----------");
    }

}
