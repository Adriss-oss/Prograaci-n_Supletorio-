package Ejercicio11;

import java.util.Scanner;

public class Triangulo {

    public void calcularArea(double x1, double y1, double x2, double y2, double x3, double y3) {
        double area = 0.5 * Math.abs(
            x1 * (y2 - y3) +
            x2 * (y3 - y1) +
            x3 * (y1 - y2));
        System.out.printf("Área del triángulo: %.2f\n", area);
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        Triangulo triangulo = new Triangulo();
        String repetir;

        do {
            System.out.println("Ingrese las coordenadas del punto P1 (x1 y1):");
            double x1 = teclado.nextDouble();
            double y1 = teclado.nextDouble();

            System.out.println("Ingrese las coordenadas del punto P2 (x2 y2):");
            double x2 = teclado.nextDouble();
            double y2 = teclado.nextDouble();

            System.out.println("Ingrese las coordenadas del punto P3 (x3 y3):");
            double x3 = teclado.nextDouble();
            double y3 = teclado.nextDouble();

            triangulo.calcularArea(x1, y1, x2, y2, x3, y3);

            System.out.print("¿Desea realizar el proceso de nuevo? (s = sí / n = no): ");
            repetir = teclado.next().toLowerCase();
            System.out.println();

        } while (repetir.equals("s"));

        System.out.println("------------------EL PROGRAMA FINALIZÓ-----------");
        teclado.close();
    }
}
