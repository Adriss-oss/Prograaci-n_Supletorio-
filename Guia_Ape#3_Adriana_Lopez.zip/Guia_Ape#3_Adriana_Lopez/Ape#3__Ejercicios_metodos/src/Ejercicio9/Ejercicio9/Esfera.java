package Ejercicio9;

import java.util.Scanner;

public class Esfera {
     // Método para calcular el área de la esfera
    public static double calcularArea(double radio) {
        return 4 * Math.PI * Math.pow(radio, 2);
    }

    // Método para calcular el volumen de la esfera
    public static double calcularVolumen(double radio) {
        return (4.0 / 3) * Math.PI * Math.pow(radio, 3);
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        char repetir;

        do {
            System.out.print("Ingrese el radio de la esfera: ");
            double radio = teclado.nextDouble();

            System.out.println("Área de la esfera: " + calcularArea(radio));
            System.out.println("Volumen de la esfera: " + calcularVolumen(radio));

            System.out.print("¿Desea repetir el proceso? (s/n): ");
            repetir = teclado.next().charAt(0);

        } while (repetir == 's' || repetir == 'S');
        System.out.println("------------------EL PROGRAMA FINALIZO-----------");
    }

}
