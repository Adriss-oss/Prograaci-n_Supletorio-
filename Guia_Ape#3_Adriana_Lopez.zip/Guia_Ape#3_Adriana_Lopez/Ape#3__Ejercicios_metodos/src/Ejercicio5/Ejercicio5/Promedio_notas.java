package Ejercicio5;

import java.util.Scanner;

public class Promedio_notas {
    private Scanner teclado;
    private double nota1, nota2, nota3;

    public void ingresarDatos() {
        teclado = new Scanner(System.in);

        System.out.println("Ingrese la primera nota:");
        nota1 = teclado.nextDouble();
        System.out.println("Ingrese la segunda nota:");
        nota2 = teclado.nextDouble();
        System.out.println("Ingrese la tercera nota:");
        nota3 = teclado.nextDouble();
    }

    public double Calcularelpromediodelasnotasmayores() {
        double suma = nota1 + nota2 + nota3;
        double menor;

        if (nota1 <= nota2 && nota1 <= nota3) {
            menor = nota1;
        } else if (nota2 <= nota1 && nota2 <= nota3) {
            menor = nota2;
        } else {
            menor = nota3;
        }

        double promedio = (suma - menor) / 2;
        System.out.println("El promedio de las dos notas mayores es: " + promedio);
        return promedio;
    }

    public static void main(String[] args) {
        Promedio_notas promedio = new Promedio_notas();
        promedio.ingresarDatos();
        promedio.Calcularelpromediodelasnotasmayores();
    }
}
