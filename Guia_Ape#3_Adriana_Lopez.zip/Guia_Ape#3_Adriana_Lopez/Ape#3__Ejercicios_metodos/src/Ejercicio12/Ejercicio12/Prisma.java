package Ejercicio12;

import java.util.Scanner;

public class Prisma {

     public void calcularAreaBase(double perimetro, double apotema) {
        double areaBase = (perimetro * apotema) / 2;
        System.out.printf("Área de la base: %.2f\n", areaBase);
    }

    public void calcularAreaLateral(double perimetro, double altura) {
        double areaLateral = perimetro * altura;
        System.out.printf("Área lateral: %.2f\n", areaLateral);
    }

    public void calcularAreaTotal(double perimetro, double apotema, double altura) {
        double areaBase = (perimetro * apotema) / 2;
        double areaLateral = perimetro * altura;
        double areaTotal = 2 * areaBase + areaLateral;
        System.out.printf("Área total: %.2f\n", areaTotal);
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        Prisma  prisma = new Prisma ();
        String repetir;
        do {
            System.out.println("Ingrese el perímetro de la base: ");
            double perimetro = teclado.nextDouble();

            System.out.println("Ingrese el apotema de la base: ");
            double apotema = teclado.nextDouble();

            System.out.println("Ingrese la altura del prisma: ");
            double altura = teclado.nextDouble();
            teclado.nextLine(); 

            if (perimetro <= 0 || apotema <= 0 || altura <= 0) {
                System.out.println("Por favor, ingrese valores positivos.");
            } else {
                prisma.calcularAreaBase(perimetro, apotema);
                prisma.calcularAreaLateral(perimetro, altura);
                prisma.calcularAreaTotal(perimetro, apotema, altura);
            }

            System.out.println("¿Desea repetir el proceso? (s=Sí / n=No): ");
            repetir = teclado.nextLine().toLowerCase();
            System.out.println();

        } while (repetir.equals("s"));

        System.out.println("------------------EL PROGRAMA FINALIZO-----------");
    }
}
