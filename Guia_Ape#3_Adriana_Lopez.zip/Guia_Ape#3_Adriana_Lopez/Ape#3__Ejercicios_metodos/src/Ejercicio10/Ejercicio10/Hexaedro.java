package Ejercicio10;

import java.util.Scanner;

public class Hexaedro {
    public static double calcularAreaBase(double lado) {
        return Math.pow(lado, 2);
    }

    // Método para calcular el área lateral
    public static double calcularAreaLateral(double lado) {
        return 4 * Math.pow(lado, 2);
    }

    // Método para calcular el área total
    public static double calcularAreaTotal(double lado) {
        return 6 * Math.pow(lado, 2);
    }

    // Método para calcular el volumen
    public static double calcularVolumen(double lado) {
        return Math.pow(lado, 3);
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        char repetir;

        do {
            System.out.print("Ingrese el lado del hexaedro: ");
            double lado = teclado.nextDouble();

            System.out.println("Área de la base: " + calcularAreaBase(lado));
            System.out.println("Área lateral: " + calcularAreaLateral(lado));
            System.out.println("Área total: " + calcularAreaTotal(lado));
            System.out.println("Volumen: " + calcularVolumen(lado));

            System.out.print("¿Desea repetir el proceso? (s/n): ");
            repetir = teclado.next().charAt(0);

        } while (repetir == 's' || repetir == 'S');
        System.out.println("------------------EL PROGRAMA FINALIZO-----------");
    }

}
