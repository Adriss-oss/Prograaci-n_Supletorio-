package Ejercicio3;

import java.util.Scanner;

public class Rango {
    public void Moatrarelpromedio(String tipo, int suma, int cantidad) {
        if (cantidad > 0) {
            double promedio = (double) suma / cantidad;
            System.out.printf("Promedio de números %s: %.2f (Cantidad: %d)%n", tipo, promedio, cantidad);
        } else {
            System.out.printf("No hay números %s en el rango.%n", tipo);
        }
    }

    public void PromedioTotal(int inicio, int fin) {
        int suma = 0, cantidad = 0;
        for (int i = inicio; i <= fin; i++) {
            suma += i;
            cantidad++;
        }
        Moatrarelpromedio("totales", suma, cantidad);
    }

    public void Promedio_numeros_pares(int inicio, int fin) {
        int suma = 0, cantidad = 0;
        for (int i = inicio; i <= fin; i++) {
            if (i % 2 == 0) {
                suma += i;
                cantidad++;
            }
        }
        Moatrarelpromedio("pares", suma, cantidad);
    }

    public void Promedio_numeros_impares(int inicio, int fin) {
        int suma = 0, cantidad = 0;
        for (int i = inicio; i <= fin; i++) {
            if (i % 2 != 0) {
                suma += i;
                cantidad++;
            }
        }
        Moatrarelpromedio("impares", suma, cantidad);
    }

    public void Promedio_numeros_primos(int inicio, int fin) {
        int suma = 0, cantidad = 0;
        for (int i = inicio; i <= fin; i++) {
            if (esPrimo(i)) {
                suma += i;
                cantidad++;
            }
        }
        Moatrarelpromedio("primos", suma, cantidad);
    }

    public boolean esPrimo(int n) {
        if (n < 2) return false;
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) return false;
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Rango Promedio = new  Rango();
        String repetir;

        do {
            System.out.print("Ingrese el número inicial del rango: ");
            int inicio = scanner.nextInt();

            System.out.print("Ingrese el número final del rango: ");
            int fin = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            if (inicio > fin) {
                System.out.println("Error: el número inicial debe ser menor o igual al final.");
            } else {
                Promedio.PromedioTotal(inicio, fin);
                Promedio.Promedio_numeros_pares(inicio, fin);
                Promedio.Promedio_numeros_impares(inicio, fin);
                Promedio.Promedio_numeros_primos(inicio, fin);
            }

            System.out.print("¿Desea realizar de nuevo el proceso? (si / no): ");
            repetir = scanner.nextLine().toLowerCase();
            System.out.println();

        } while (repetir.equals("si"));

        System.out.println("------------------EL PROGRAMA FINALIZO-----------");
    }

}
