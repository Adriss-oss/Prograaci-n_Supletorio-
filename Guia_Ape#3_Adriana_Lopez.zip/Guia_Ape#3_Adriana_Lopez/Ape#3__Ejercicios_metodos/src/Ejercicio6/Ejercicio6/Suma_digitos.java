package Ejercicio6;

import java.util.Scanner;

public class Suma_digitos {
     public void SumaDigitosPares(int numero) {
        int suma = 0;
        int temp = numero;

        while (temp > 0) {
            int digito = temp % 10;
            if (digito % 2 == 0) {
                suma += digito;
            }
            temp /= 10;
        }

        System.out.println("Suma de dígitos pares: " + suma);
    }
    public void SumaDigitosImpares(int numero) {
        int suma = 0;
        int temp = numero;

        while (temp > 0) {
            int digito = temp % 10;
            if (digito % 2 != 0) {
                suma += digito;
            }
            temp /= 10;
        }
        System.out.println("Suma de dígitos impares: " + suma);
    }
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        Suma_digitos sumas = new Suma_digitos();
        String repetir;

        do {
            System.out.println("Ingrese un número positivo: ");
            int numero = teclado.nextInt();
            teclado.nextLine(); 

            if (numero < 0) {
                System.out.println("Por favor, ingrese un número positivo.");
            } else {
                sumas.SumaDigitosPares(numero);
                sumas.SumaDigitosImpares(numero);
            }
            System.out.println("desea realizar de nuevo s=si o n=no");
            repetir = teclado.nextLine().toLowerCase();
            System.out.println();

        } while (repetir.equals("s"));

        System.out.println("------------------EL PROGRAMA FINALIZO-----------");
    }

}
