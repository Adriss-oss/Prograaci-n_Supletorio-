package Ejercicio1;

import java.util.Scanner;
public class Factorial {
    // el factorial 
    public void CalacularFactorial(int num) {
        int factorial = 1;
        for (int i = 1; i <= num; i++) {
            factorial *= i;
        }
        System.out.println("El factorial de " + num + " es: " + factorial);
    }
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese el numero para el factorial");
        int num = teclado.nextInt();
        Factorial factorial1= new Factorial();
        factorial1.CalacularFactorial(num);
    }
}