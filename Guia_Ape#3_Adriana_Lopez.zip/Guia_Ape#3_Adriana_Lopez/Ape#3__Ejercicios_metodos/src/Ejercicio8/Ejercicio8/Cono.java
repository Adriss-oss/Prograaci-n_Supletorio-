package Ejercicio8;

import java.util.Scanner;

public class Cono {
      public void areaBase(double radio) {
        double area = 3.14 * Math.pow(radio, 2);
        System.out.printf("Área de la base: %.2f\n", area);
    }

    //  Formula para el área lateral (π * r * g)
    public void areaLateral(double radio, double generatriz) {
        double area = 3.14 * radio * generatriz;
        System.out.printf("Área lateral: %.2f\n", area);
    }

    // Fomula el área  (área base + área lateral)
    public void areaTotal(double radio, double generatriz) {
        double areaBase = 3.14 * Math.pow(radio, 2);
        double areaLateral = 3.14 * radio * generatriz;
        double areaTotal = areaBase + areaLateral;
        System.out.printf("Área total: %.2f\n", areaTotal);
    }

    //  Formula del volumen ((1/3) * π * r² * h)
    public void volumen(double radio, double altura) {
        double volumen = (1.0 / 3) * 3.14 * Math.pow(radio, 2) * altura;
        System.out.printf("Volumen: %.2f\n", volumen);
    }
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        Cono cono = new Cono();
        String repetir;

        do {
            System.out.println("Ingrese el radio del cono: ");
            double radio = teclado.nextDouble();

            System.out.println("Ingrese la generatriz del cono: ");
            double generatriz = teclado.nextDouble();

            System.out.println("Ingrese la altura del cono: ");
            double altura = teclado.nextDouble();
            teclado.nextLine(); 

            cono.areaBase(radio);
            cono.areaLateral(radio, generatriz);
            cono.areaTotal(radio, generatriz);
            cono.volumen(radio, altura);

            System.out.println("desea realizar de nuevo s=si o n=no");
            repetir = teclado.nextLine().toLowerCase();
            System.out.println();

        } while (repetir.equals("s"));

       System.out.println("------------------EL PROGRAMA FINALIZO-----------");
    }

}
