package Examen;

public class Ejercicio_1 {
    
    private int numero;

    public void Numerosprimos(){
        int vector[]= new int[350];
        for (int i = 0; i < vector.length; i++) 

            
        }

    }

       
        
    

    public static void main(String[] args) {
        Ejercicio_1 num_prim = new Ejercicio_1();

        

        
    }
}
