package Examen;

import java.util.Random;
import java.util.Scanner;

public class Ejercicio_2 {
    
    
    private Scanner teclado;
    
    public static void Ingresarvector1(){

         int Vector_1[] = new int[10];
        Random num_ram = new Random();
        for (int i = 0; i <= Vector_1.length; i++) {
            Vector_1[i]=num_ram.nextInt();
        }
        
    }
    public static  void Ingresarvector2(){
        int Vector_2[] = new int[10];
        Random num_ram = new Random();
        for (int i = 0; i <= Vector_2.length; i++) {
            Vector_2[i]=num_ram.nextInt(); 
        }

    }
    public static void Restavectores(int Vector_1[i],int Vector_2[i]){
        int resta[] = new int[10];
        for (int j = 0; j < resta.length; j++) {
            resta[j]=Vector_1[i]-Vector_2[i];
                }
    }
    public static void Productovectores(int Vector_1[i],int Vector_2[i]){
        int producto[] = new int[10];
        for (int j = 0; j < resta.length; j++) {
            producto[j]=Vector_1[i]*Vector_2[i];
                }
    }
    public static void residuovectores(int Vector_1[i],int Vector_2[i]){
        int residuo[] = new int[10];
        for (int j = 0; j < resta.length; j++) {
            residuo[j]=Vector_1[i]%Vector_2[i];
                }
    }
    public static void mayorvectores(int Vector_1[i],int Vector_2[i]){
        if (Vector_1[i]>Vector_2[i]) {
           int mayor=Vector_1[i]; 
        }else{
           int mayor=Vector_2[i];
        }
    }
    public static void menorvectores(int Vector_1[i],int Vector_2[i]){
        if (Vector_1[i]<Vector_2[i]) {
           int menor=Vector_1[i]; 
        }else{
           int menor=Vector_2[i];
        }
    }
    public static void mayorvectores(){
        if (Vector_1[i]>Vector_2[i]) {
           int mayor=Vector_1[i]; 
        }else{
           int mayor=Vector_2[i];
        }
    }

    public static void main(String[] args) {
        Ejercicio_2 tabla = new Ejercicio_2();
        tabla.Ingresarvectore1();
        
    }

}
