import java.util.Scanner;

public class Ejercicio_6 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        float nota;
        System.out.println("Ingresar la nota de el Estudiante: ");
        System.out.println("ingresar de un rago de 0 a 100");
        nota=teclado.nextFloat();
        if (nota>=90){
            System.out.println("Su nota es de  "+nota+" obtiene una A");
        }else{
            if (nota>=80 & nota<90){
        System.out.println("Su nota es de  "+nota+" Obtiene una B");
                }else{
            if (nota>80 & nota>=70) {
                System.out.println("Su nota es de  "+nota+ " Obtiene una C");
            }else {
                    if (nota<70 & nota>=69){
                        System.out.println("Su nota es de  "+nota+" Obtienenuna D");
                    }else{
                        System.out.println("Su nota es de "+nota+" Obtiene una F");
                    }
                }
            }
        }

    }

}
