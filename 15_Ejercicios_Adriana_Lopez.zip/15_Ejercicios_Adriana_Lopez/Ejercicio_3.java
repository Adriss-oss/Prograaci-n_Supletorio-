import java.util.Scanner;

public class Ejercicio_3 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int num,res;
        System.out.println("Ingresar un número: ");
        num=teclado.nextInt();
         res=num%2;
         if (res==0) {
            System.out.println(num +" Es par " );
         }
         else{
            System.out.println(num+" Es impar ");
         }
    }

}
