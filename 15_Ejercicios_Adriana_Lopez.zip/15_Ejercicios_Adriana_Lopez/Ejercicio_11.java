import java.util.Scanner;

public class Ejercicio_11 {
    /**
     * @param args
     */
    public static void main(String[] args) {
        
        Scanner teclado= new Scanner(System.in);
        double monto_compra,desc=0,descuento=0;
        System.out.println("Ingresar el monto de la compra");
        monto_compra=teclado.nextDouble();
        if (monto_compra>=500){
            descuento=20;
             desc=monto_compra*0.2;
        }else{
            if (monto_compra>=100) {   
                descuento=10; 
                desc=monto_compra-(monto_compra*0.1);
            }
        }
        System.out.println("El descuento realizado es de: "+ descuento+"%");
        System.out.println("EL VALOR A PAGAR ES DE $"+desc);
        
    }

}
