import java.util.Scanner;

public class Ejercicio_12 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double lado_1,lado_2,lado_3;
        System.out.println("Ingresar el primer lado para el triangulo");
        lado_1=teclado.nextDouble();
        System.out.println("Ingresar el segundo lado para el triangulo");
        lado_2=teclado.nextDouble();
        System.out.println("Ingresar el tercer lado para el triangulo");
        lado_3=teclado.nextDouble();
        if (lado_1==lado_2 && lado_2==lado_3){
            System.out.println(" Es un triangulo  EQUILATERO");
        }else{
            if (lado_1 == lado_2 || lado_1 == lado_3 || lado_2 == lado_3) {
                System.out.println("Es un triangulo ISÓSELES");
            }else{
                if ((lado_1!=lado_2) & (lado_2!=lado_3) & (lado_3!=lado_1) ) {
                    System.out.println("Es un triangulo  ESCALENO");
                }else{
                    System.out.println("Los valores ingresados no cumplen con la DESIGUALDAD TRIANGULAR");
                    System.out.println("    POR ESTA RAZON ES INVALIDO ");
    }
            }
        }
    }
    

}
