import java.util.Scanner;

public class ejercicio_1 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int num1,num2,num3;
        System.out.println("Ingresar el primer número: ");
        num1=teclado.nextInt();
        System.out.println("Ingresar el segundo número: ");
        num2=teclado.nextInt();
        System.out.println("Ingresar el tercer número: ");
        num3=teclado.nextInt();

        if (num1>num2 && num1>num3 && num2>num3) {
            System.out.println("El número del medio es: " + num2);
        } else {
            if (num2>num1 && num2>num3 && num1>num3) {
                System.out.println("El número del medio es: " + num1);
            } else 
                if (num2>num1 && num2>num3 && num3>num1) {
                System.out.println("El número del medio es: " + num3);
            }
        }
        teclado.close();
    }

}
