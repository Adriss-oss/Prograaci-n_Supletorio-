import java.util.Scanner;

public class Ejercicio_9 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        int dia_actual,mes_actual,anio_actual,dia_nac,mes_nac,anio_nac,anios,meses,dias;
        // Ingresar de fecha de nacimiento 
        System.out.println("Ingresar la fecha de nacimiento (día/mes/año): ");
        System.out.println("Ingresar el dia nacimiento:");
        dia_nac = teclado.nextInt();
        System.out.println("Ingresar el mes nacimiento:");
        mes_nac = teclado.nextInt();
        System.out.println("Ingresar el año nacimiento:");
        anio_nac = teclado.nextInt();
        // Ingresar de fecha actual 
        System.out.println("Ingresar la fecha actual (día/mes/año): ");
        System.out.println("Ingresar el dia actual:");
        dia_actual = teclado.nextInt();
        System.out.println("Ingresar el mes actual:");
        mes_actual = teclado.nextInt();
        System.out.println("Ingresar el año actual:");
        anio_actual = teclado.nextInt();
        anios = anio_actual - anio_nac;
        meses = mes_actual - mes_nac;
        dias = dia_actual - dia_nac;
        if (dias < 0) {
            // se asume un mes de 30 días
            dias += 30; 
            meses--;
        }
        if (meses < 0) {
            meses += 12;
            anios--;
        }

        if (anios <= 0) {
            System.out.println("Edad: " + meses + " meses y " + dias + " días.");
        } else {
            System.out.println("Edad: " + anios + " años.");
        }
    }

}
