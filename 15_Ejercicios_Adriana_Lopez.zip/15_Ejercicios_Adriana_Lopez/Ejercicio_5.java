import java.util.Scanner;

public class Ejercicio_5 {
    public static void main(String[] args) {
        
        Scanner teclado= new Scanner(System.in);
        int num1,num2,res,res2;
        System.out.println("Ingresar el primer número");
        num1=teclado.nextInt();
        System.out.println("Ingresar el segundo número");
        num2=teclado.nextInt();
        res=num1%num2;
        res2=num2%num1;
        if (res==0) {
            System.out.println(num1 +" Si es divisor de "+num2);
        }
        else{
            if (res2==0) {
                System.out.println(num2 +" Si es divisor de "+num1);
            }else {
                System.out.println("Ninguno e los dos números es divisor del otro");
            }
        }
    }
}
