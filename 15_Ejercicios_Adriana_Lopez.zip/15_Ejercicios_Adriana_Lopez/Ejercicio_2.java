import java.util.Scanner;

public class Ejercicio_2 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double num,raiz;
        System.out.println("CALCULAR LA RAIZ ");
        System.out.println("Ingresar un numero : ");
        num=teclado.nextDouble();
        if (num>0) {
            raiz=Math.sqrt(num);
            System.out.println("La raiz de "+num+" es: "+raiz);
        }
        else{
            System.out.println("No existe raiz para numero negativo");
        }
    }
}
