import java.util.Scanner;
public class Ejercicio_4 {
        public static void main(String[] args) {
            Scanner teclado = new Scanner(System.in);
            int dia, mes, anio;
            System.out.print("Ingresar el día: ");
            dia = teclado.nextInt();
    
            System.out.print("Ingresar el mes: ");
            mes = teclado.nextInt();
    
            System.out.print("Ingresar el año: ");
            anio = teclado.nextInt();
    
            // Validar el rango de mes que debe ser entre 1 y 12 meses 
            if (mes < 1 || mes > 12) {
                System.out.println(" El mes es inválido. Debe estar entre  1 y 12.");
            }

            int diasMes = 31;
            // Calcular días del mes
            if (mes == 4 || mes == 6 || mes == 9 || mes == 11) {
                diasMes = 30;
            } else if (mes == 2) {
                // Tomamos en cunta si esque el aaño es bisiesto 
                if ((anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0)) {
                    diasMes = 29;
                } else {
                    diasMes = 28;
                }
            }
    
            // Validamos el dia ingresado 
            if (dia < 1 || dia > diasMes) {
                System.out.println(" Día inválido para el mes ingresado.");
            }
    
            // obtenemos los resultados de la siguiente fecha 
            
            dia++;
            if (dia > diasMes) {
                dia = 1;
                mes++;
                if (mes > 12) {
                    mes = 1;
                    anio++;
                }
            }
    
            System.out.println("La fecha del día siguiente es: " + dia + "/" + mes + "/" + anio);
    
            teclado.close();
        }
    
}
