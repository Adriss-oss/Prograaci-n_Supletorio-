import java.util.Scanner;

public class Ejercicio_10 {
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        double num1,num2,sum,rest,mult,div;
        String Op;
        System.out.println("Ingresar el primer número: ");
        num1=teclado.nextDouble();
        System.out.println("Ingresar el segundo número: ");
        num2=teclado.nextDouble();
        System.out.println("Ingrese el SIGNO  de la operacion que desee realizar");
        System.out.println("+)SUMA");
        System.out.println("-)RESTA");
        System.out.println("*)MULTIPLICACIÓN");
        System.out.println("/)DIVISIÓN");
        Op=teclado.next();
        switch (Op) {

          case "+":
               System.out.println("HA SELECCIONADO SUMA");
               sum=num1+num2;
               System.out.println(+num1+" + "+num2+" = "+sum);
                break;
          case "-": 
               System.out.println("HA SELECCIONADO RESTA");
               sum=num1-num2;
               System.out.println(+num1+" - "+num2+" = "+sum);
                 break;
          case "*":  
               System.out.println("HA SELECCIONADO MULTIPLICACIÓN");
               sum=num1*num2;
               System.out.println(+num1+" * "+num2+" = "+sum);
                break;
          case "/": 
               if (num2==0) {
                System.out.println("La operacion no se puede realizar");
                System.out.println("Es un error matemático, no se piede dividir para 0");
               }else{
                System.out.println("HA SELECCIONADO DIVISIÓN");
                sum=num1/num2;
                System.out.println(+num1+" / "+num2+" = "+sum);
               }
                 break;
            default:
              System.out.println("¡¡OPCION NO VALIDA!!");
              System.out.println("Ingresar una opcion valida");
                break;
        }
        
    }


}
