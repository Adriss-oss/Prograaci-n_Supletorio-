import java.util.Random;
import java.util.Scanner;

public class Ejercicio_13 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
          Random random = new Random();
        int puntos_usuario = 0,puntos_computadora = 0,ronda = 1;
        while (puntos_usuario < 2 && puntos_computadora < 2) {
            System.out.println("\nRonda " + ronda + ":");
            System.out.println("Elige: 1. Piedra, 2. Papel, 3. Tijeras");

            int eleccion_usuario = 0;
            boolean entrada_valida = false;

            while (!entrada_valida) {
                if (teclado.hasNextInt()) {
                    eleccion_usuario = teclado.nextInt();
                    if (eleccion_usuario >= 1 && eleccion_usuario <= 3) {
                        entrada_valida = true;
                    } else {
                        System.out.println("Entrada inválida. Elige 1, 2 o 3.");
                    }
                } else {
                    System.out.println("Entrada inválida. Ingresa un número.");
                    teclado.next(); // Limpiar la entrada inválida
                }
            }

            int eleccionComputadora = random.nextInt(3) + 1; 

            System.out.println("Tu elección: " + obtenerNombre(eleccion_usuario));
            System.out.println("Elección de la computadora: " + obtenerNombre(eleccionComputadora));

            int resultado = determinarGanador(eleccion_usuario, eleccionComputadora);

            if (resultado == 0) {
                System.out.println("Empate.");
            } else if (resultado == 1) {
                System.out.println("¡Ganaste la ronda!");
                puntos_usuario++;
            } else {
                System.out.println("La computadora gana la ronda.");
                puntos_computadora++;
            }

            System.out.println("Puntaje: Tú " + puntos_usuario + " - Computadora " + puntos_computadora);
            ronda++;
        }

        System.out.println("\nResultado final:");
        if (puntos_usuario > puntos_computadora) {
            System.out.println("¡Ganaste el juego!");
        } else {
            System.out.println("La computadora gana el juego.");
        }
    }

    public static String obtenerNombre(int eleccion) {
        switch (eleccion) {
            case 1:
                return "Piedra";
            case 2:
                return "Papel";
            case 3:
                return "Tijeras";
            default:
                return "";
        }
    }

    public static int determinarGanador(int eleccionUsuario, int eleccionComputadora) {
        if (eleccionUsuario == eleccionComputadora) {
            return 0; // Empate
        } else if ((eleccionUsuario == 1 && eleccionComputadora == 3) ||
                   (eleccionUsuario == 2 && eleccionComputadora == 1) ||
                   (eleccionUsuario == 3 && eleccionComputadora == 2)) {
            return 1; // Usuario gana
        } else {
            return 2; // Computadora gana
        }

    }
}
